/**
 * Mock AI Service to simulate analysis from top AI systems
 * This service provides simulated market insights and recommendations
 * based on hypothetical AI analysis of OTC trading patterns and market data
 */
export const mockAiService = {
  /**
   * Get AI-powered market analysis for OTC trading
   * Simulates analysis from top AI systems
   */
  getMarketAnalysis: async (currency: string = 'EACO') => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock AI analysis data based on different time periods
    const timePeriods = ['24h', '7d', '30d'];
    const analysisByPeriod = timePeriods.reduce((acc, period) => {
      // Generate random but realistic-looking market data
      const volatility = (Math.random() * 5) + 1; // 1-6% volatility
      const trendScore = (Math.random() * 100); // 0-100 trend strength
      const trendDirection = trendScore > 50 ? 'bullish' : 'bearish';
      const recommendationScore = Math.min(Math.max(trendScore + (Math.random() * 20 - 10), 0), 100);
      
      acc[period] = {
        volatility: parseFloat(volatility.toFixed(2)),
        trendScore: parseFloat(trendScore.toFixed(2)),
        trendDirection,
        recommendationScore: parseFloat(recommendationScore.toFixed(2)),
        recommendation: recommendationScore > 70 ? 'strong_buy' : 
                       recommendationScore > 50 ? 'buy' :
                       recommendationScore > 30 ? 'hold' :
                       recommendationScore > 10 ? 'sell' : 'strong_sell',
        volumeChange: parseFloat((Math.random() * 40 - 10).toFixed(2)), // -10% to +30% volume change
        priceChange: parseFloat((Math.random() * 15 - 5).toFixed(2)), // -5% to +10% price change
        // Simulated AI confidence score (0-100)
        confidenceScore: parseFloat((70 + Math.random() * 30).toFixed(2))
      };
      
      return acc;
    }, {});
    
    // Generate AI recommendations based on analysis
    const overallRecommendation = analysisByPeriod['7d'].recommendation;
    const priceTarget = 0.8 + Math.random() * 0.4; // Random price target between $0.80 and $1.20
    
    return {
      currency,
      timestamp: new Date().toISOString(),
      analysisByPeriod,
      overallRecommendation,
      priceTarget: parseFloat(priceTarget.toFixed(4)),
      // Simulate AI insights from top systems
      insights: [
        `Based on pattern recognition, there's a ${Math.round(Math.random() * 40 + 50)}% probability of ${analysisByPeriod['7d'].trendDirection} continuation`,
        `Volume analysis indicates increased institutional interest in ${currency} OTC markets`,
        `Optimal trading windows identified: ${['03:00-05:00 UTC', '12:00-14:00 UTC', '18:00-20:00 UTC'][Math.floor(Math.random() * 3)]}`,
        `Price volatility forecast: ${analysisByPeriod['24h'].volatility > 3 ? 'High' : 'Moderate'} for next 24 hours`,
        `AI sentiment analysis shows ${Math.round(Math.random() * 30 + 50)}% positive sentiment in ${currency} community channels`
      ],
      // Simulate risk assessment from AI
      riskAssessment: {
        overallRisk: ['Low', 'Moderate', 'Moderate', 'High'][Math.floor(Math.random() * 4)],
        factors: [
          { name: 'Market Volatility', score: Math.random() * 10, maxScore: 10 },
          { name: 'Liquidity Risk', score: Math.random() * 5, maxScore: 10 },
          { name: 'Regulatory Risk', score: Math.random() * 3, maxScore: 10 },
          { name: 'Counterparty Risk', score: Math.random() * 7, maxScore: 10 }
        ]
      },
      // Simulate optimization recommendations
      optimizationRecommendations: [
        {
          category: 'pricing',
          suggestion: `Adjust OTC prices by ${parseFloat((Math.random() * 2).toFixed(1))}% to improve competitiveness`,
          potentialImpact: `+${parseFloat((Math.random() * 15 + 5).toFixed(1))}% trading volume`
        },
        {
          category: 'liquidity',
          suggestion: `Add ${['USDC', 'USDT', 'SOL'][Math.floor(Math.random() * 3)]} as additional settlement option`,
          potentialImpact: `+${parseFloat((Math.random() * 20 + 10).toFixed(1))}% order fulfillment rate`
        },
        {
          category: 'timing',
          suggestion: `Schedule large orders during identified low-volatility windows`,
          potentialImpact: `- ${parseFloat((Math.random() * 3 + 1).toFixed(1))}% execution risk`
        }
      ]
    };
  },
  
  /**
   * Get AI-powered price prediction for a specific currency pair
   */
  getPricePrediction: async (baseCurrency: string, targetCurrency: string) => {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Generate a realistic-looking price prediction
    const basePrice = Math.random() * 0.5 + 0.8; // Base price between $0.80 and $1.30
    const predictionPoints = [1, 6, 12, 24, 48, 72].map(hours => {
      // Generate price with slight variation over time
      const variation = (Math.random() - 0.45) * 0.15 * basePrice; // -4.5% to +10.5% variation
      const predictedPrice = basePrice + variation;
      const confidence = 50 + Math.random() * 40; // 50-90% confidence
      
      return {
        hours,
        price: parseFloat(predictedPrice.toFixed(4)),
        confidence: parseFloat(confidence.toFixed(1)),
        trend: predictedPrice > basePrice ? 'up' : predictedPrice < basePrice ? 'down' : 'flat'
      };
    });
    
    return {
      pair: `${baseCurrency}/${targetCurrency}`,
      currentPrice: parseFloat(basePrice.toFixed(4)),
      predictionPoints,
      trend: predictionPoints[predictionPoints.length - 1].price > basePrice ? 'bullish' : 'bearish',
      confidenceScore: parseFloat(((predictionPoints.reduce((sum, p) => sum + p.confidence, 0) / predictionPoints.length) / 100).toFixed(2))
    };
  },
  
  /**
   * Analyze OTC order book and provide optimization suggestions
   */
  analyzeOrderBook: async (orders: any[]) => {
    await new Promise(resolve => setTimeout(resolve, 600));
    
    // Simple order book analysis
    const buyOrders = orders.filter(o => o.type === 'buy').sort((a, b) => b.price - a.price);
    const sellOrders = orders.filter(o => o.type === 'sell').sort((a, b) => a.price - b.price);
    
    // Identify support and resistance levels
    const supportLevel = buyOrders.length > 0 ? buyOrders[0].price * 0.98 : 0;
    const resistanceLevel = sellOrders.length > 0 ? sellOrders[0].price * 1.02 : 0;
    
    // Find optimal entry points
    const optimalBuyPrice = buyOrders.length > 0 ? 
      parseFloat((buyOrders[0].price * (1 - (Math.random() * 0.03))).toFixed(4)) : 0;
      
    const optimalSellPrice = sellOrders.length > 0 ? 
      parseFloat((sellOrders[0].price * (1 + (Math.random() * 0.03))).toFixed(4)) : 0;
    
    // Detect order book anomalies
    const anomalies = [];
    if (buyOrders.length > 3) {
      const priceDiff = buyOrders[0].price - buyOrders[2].price;
      if (priceDiff > buyOrders[0].price * 0.1) { // 10% price difference between top 3 buy orders
        anomalies.push({
          type: 'buy_wall_anomaly',
          description: 'Significant price gap between top buy orders',
          severity: 'medium',
          recommendation: 'Consider limit orders at multiple price levels'
        });
      }
    }
    
        const liquidityScore = parseFloat((Math.random() * 40 + 60).toFixed(1)); // 60-100 liquidity score
        
        return {
            supportLevel: parseFloat(supportLevel.toFixed(4)),
            resistanceLevel: parseFloat(resistanceLevel.toFixed(4)),
            optimalBuyPrice,
            optimalSellPrice,
            orderDistribution: {
                buyOrders: buyOrders.length,
                sellOrders: sellOrders.length,
                buySellRatio: parseFloat((buyOrders.length / Math.max(sellOrders.length, 1)).toFixed(2))
            },
            anomalies,
            liquidityScore,
            liquidityRecommendation: liquidityScore < 70 ? 
                'Low liquidity detected. Consider smaller order sizes or alternative trading pairs.' :
                'Good liquidity conditions for current market conditions.'
        };
  },
  
  /**
   * Analyze user trading patterns and provide personalized recommendations
   */
  analyzeUserTradingPatterns: async (userId: string) => {
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    // Mock trading pattern analysis
    return {
      tradingStyle: ['scalper', 'day_trader', 'swing_trader', 'long_term_holder'][Math.floor(Math.random() * 4)],
      averageTradeSize: parseFloat((Math.random() * 900 + 100).toFixed(2)),
      preferredCurrencies: ['EACO', 'USDC', 'USDT', 'SOL'].sort(() => 0.5 - Math.random()).slice(0, 3),
      typicalHoldTime: ['minutes', 'hours', 'days', 'weeks'][Math.floor(Math.random() * 4)],
      successRate: parseFloat((Math.random() * 30 + 50).toFixed(1)), // 50-80% success rate
      riskScore: parseFloat((Math.random() * 40 + 30).toFixed(1)), // 30-70 risk score
      recommendations: [
        `Based on your ${['scalping', 'day trading', 'swing trading', 'long-term holding'][Math.floor(Math.random() * 4)]} style, consider adjusting order sizes by ${parseFloat((Math.random() * 20 + 10).toFixed(0))}%`,
        `Your trading success rate increases by ${parseFloat((Math.random() * 10 + 5).toFixed(1))}% during ${['morning', 'afternoon', 'evening'][Math.floor(Math.random() * 3)]} hours`,
        `Diversify with ${['USDC', 'SOL', 'BTC'][Math.floor(Math.random() * 3)]} to reduce portfolio volatility by an estimated ${parseFloat((Math.random() * 15 + 5).toFixed(1))}%`,
        `Consider using limit orders instead of market orders to improve entry prices by an average of ${parseFloat((Math.random() * 2 + 0.5).toFixed(2))}%`
      ],
      performanceBenchmarks: [
        { metric: 'ROI', your: parseFloat((Math.random() * 20 + 5).toFixed(1)), average: parseFloat((Math.random() * 15 + 3).toFixed(1)) },
        { metric: 'Win Rate', your: parseFloat((Math.random() * 20 + 60).toFixed(1)), average: parseFloat((Math.random() * 15 + 50).toFixed(1)) },
        { metric: 'Risk/Reward', your: parseFloat((Math.random() * 1 + 1.5).toFixed(1)), average: parseFloat((Math.random() * 1 + 1).toFixed(1)) }
      ]
    };
  },
  
  /**
   * Get automated code optimization suggestions
   * Simulates AI-powered code analysis and optimization recommendations
   */
  getCodeOptimizations: async () => {
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock code optimization suggestions
    return {
      performanceImprovements: [
        {
          component: 'OrderBook',
          issue: 'Excessive re-renders on price updates',
          solution: 'Implement virtualized list rendering for large order books',
          potentialGain: '60-70% reduction in render time for large datasets'
        },
        {
          component: 'ExchangeForm',
          issue: 'Inefficient state updates',
          solution: 'Optimize state management with useMemo and useCallback hooks',
          potentialGain: '30-40% improvement in form responsiveness'
        },
        {
          component: 'TransactionHistory',
          issue: 'Unoptimized data fetching',
          solution: 'Implement pagination and lazy loading for transaction history',
          potentialGain: '50-60% reduction in initial page load time'
        }
      ],
      codeQualityImprovements: [
        {
          file: 'useExchange.ts',
          issue: 'Complex function with multiple responsibilities',
          solution: 'Refactor into smaller, focused custom hooks',
          benefit: 'Improved maintainability and testability'
        },
        {
          file: 'OTCTrading.tsx',
          issue: 'Excessive component complexity',
          solution: 'Break down into smaller, reusable components',
          benefit: 'Better code organization and reusability'
        },
        {
          file: 'types/transaction.ts',
          issue: 'Incomplete type definitions',
          solution: 'Add more specific type annotations and interfaces',
          benefit: 'Improved type safety and developer experience'
        }
      ],
      accessibilityImprovements: [
        {
          component: 'OrderDetails',
          issue: 'Poor keyboard navigation',
          solution: 'Add proper tab indexing and keyboard event handlers',
          benefit: 'Compliance with WCAG 2.1 AA standards'
        },
        {
          component: 'CreateOrderForm',
          issue: 'Inadequate form labels and error messages',
          solution: 'Improve form accessibility with proper ARIA attributes',
          benefit: 'Better screen reader support and overall UX'
        }
      ]
    };
  }
};

// Helper function to format AI analysis results for display
export const formatAiAnalysis = (analysis: any) => {
  return {
    ...analysis,
    insights: analysis.insights.map((insight: string, index: number) => ({
      id: `insight-${index}`,
      text: insight,
      confidence: parseFloat((70 + Math.random() * 30).toFixed(1))
    }))
  };
};