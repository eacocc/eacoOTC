import { Routes, Route } from "react-router-dom";
import { Suspense } from "react";
import Home from "@/pages/Home";
import Exchange from "@/pages/Exchange";
import OTCTradingPage from "@/pages/OTCTrading";
import TransactionHistory from "@/pages/TransactionHistory";
import { AuthContext } from '@/contexts/authContext';
import { useState } from "react";
import { WalletAdapterNetwork } from '@solana/wallet-adapter-base';
import { WalletProvider } from '@solana/wallet-adapter-react';
import { PhantomWalletAdapter } from '@solana/wallet-adapter-phantom';
import { useTranslation } from 'react-i18next';
import '@/locales';

// Lazy-loaded components
const HelpPage = React.lazy(() => import('@/pages/Help'));

export default function App() {
  const { t } = useTranslation();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [network, setNetwork] = useState(WalletAdapterNetwork.Mainnet);
  
  // Initialize wallets
  const wallets = [new PhantomWalletAdapter()];

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, setIsAuthenticated, logout }}
    >
      <WalletProvider wallets={wallets} network={network}>
        <Suspense fallback={<div className="flex justify-center items-center min-h-screen">{t('common.loading')}...</div>}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/exchange" element={<Exchange />} />
            <Route path="/history" element={<TransactionHistory />} />
            <Route path="/otc" element={<OTCTradingPage />} />
            <Route path="/help" element={<HelpPage />} />
            <Route path="*" element={<div className="text-center text-xl p-8">Page not found</div>} />
          </Routes>
        </Suspense>
      </WalletProvider>
    </AuthContext.Provider>
  );
}
