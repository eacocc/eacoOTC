import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Navbar } from '@/components/layout/Navbar';
import { OrderBook } from '@/components/otc/OrderBook';
import { CreateOrderForm } from '@/components/otc/CreateOrderForm';
import { MyOrders } from '@/components/otc/MyOrders';
import { OrderDetails } from '@/components/otc/OrderDetails';
import { useExchange } from '@/hooks/useExchange';
import { OTCOrder } from '@/types/transaction';

export default function OTCTradingPage() {
  const { t } = useTranslation();
  const { otcOrders, myOtcOrders, matchOTCOrder, releaseEscrow, openDispute } = useExchange();
  const [activeTab, setActiveTab] = useState<'order_book' | 'my_orders'>('order_book');
  const [selectedOrder, setSelectedOrder] = useState<OTCOrder | null>(null);
  const [showOrderDetails, setShowOrderDetails] = useState(false);
  const [showDisputeModal, setShowDisputeModal] = useState(false);
  const [disputeReason, setDisputeReason] = useState('');
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiPricePrediction, setAiPricePrediction] = useState<any>(null);
  const [aiOrderBookAnalysis, setAiOrderBookAnalysis] = useState<any>(null);

  // Handle order selection
  const handleOrderSelect = (order: OTCOrder) => {
    setSelectedOrder(order);
    setShowOrderDetails(true);
  };

  // Close order details modal
  const handleCloseDetails = () => {
    setShowOrderDetails(false);
    setSelectedOrder(null);
  };

  // Dispute modal handlers
  const handleOpenDisputeModal = () => {
    setShowDisputeModal(true);
  };

  const handleCloseDisputeModal = () => {
    setShowDisputeModal(false);
    setDisputeReason('');
  };

  // AI Market Analysis handler
  const fetchAiMarketAnalysis = () => {
    // Implementation would go here
    setIsAnalyzing(true);
    // Simulated API call
    setTimeout(() => {
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">{t('otc.title')}</h1>
          
          {/* OTC Tabs */}
          <div className="border-b border-gray-200 mb-6">
            <nav className="-mb-px flex space-x-8">
              <button
                onClick={() => setActiveTab('order_book')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'order_book'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {t('otc.order_book')}
              </button>
              <button
                onClick={() => setActiveTab('my_orders')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'my_orders'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {t('otc.my_orders')}
              </button>
            </nav>
          </div>
          
          {/* Tab Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content Area */}
            <div className="lg:col-span-2 space-y-6">
              {activeTab === 'order_book' ? (
                <OrderBook 
                  orders={otcOrders} 
                  onOrderSelect={handleOrderSelect} 
                />
              ) : (
                <MyOrders 
                  orders={myOtcOrders} 
                  onOrderSelect={handleOrderSelect}
                />
              )}
            </div>
            
            {/* Sidebar - Create Order Form */}
            <div>
              <CreateOrderForm />
            </div>
          </div>
        </div>
      </main>
      
       {/* Order Details Modal */}
       {showOrderDetails && selectedOrder && (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
           <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto transform transition-all">
             <OrderDetails 
               order={selectedOrder} 
               onClose={handleCloseDetails}
               onReleaseFunds={releaseEscrow}
             />
           </div>
         </div>
       )}
       
       {/* Dispute Modal */}
       {showDisputeModal && selectedOrder && (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
           <div className="bg-white rounded-lg max-w-md w-full p-6 transform transition-all">
             <h3 className="text-xl font-bold text-gray-800 mb-4">{t('otc.open_dispute')}</h3>
             <p className="text-gray-600 mb-4">{t('otc.dispute_instructions')}</p>
             
             <textarea
               className="w-full p-3 border border-gray-300 rounded-lg mb-4"
               rows={4}
               placeholder={t('otc.dispute_reason_placeholder')}
               value={disputeReason}
               onChange={(e) => setDisputeReason(e.target.value)}
             ></textarea>
             
             <div className="flex justify-end space-x-3">
               <button
                 onClick={handleCloseDisputeModal}
                 className="px-4 py-2 border border-gray-300 rounded-lg"
               >
                 {t('common.cancel')}
               </button>
               <button
                 onClick={() => {
                   openDispute(selectedOrder.id, disputeReason);
                   handleCloseDisputeModal();
                 }}
                 className="px-4 py-2 bg-red-600 text-white rounded-lg"
                 disabled={!disputeReason.trim()}
               >
                 {t('otc.submit_dispute')}
               </button>
             </div>
           </div>
         </div>
       )}
     
     {/* AI Analysis Panel */}
     <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
       <div className="flex justify-between items-center mb-6">
         <h2 className="text-xl font-bold text-gray-800 flex items-center">
           <i className="fa-solid fa-robot text-blue-500 mr-2"></i>
           AI-Powered Market Insights
         </h2>
         <button
           onClick={() => fetchAiMarketAnalysis()}
           disabled={isAnalyzing}
           className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
             isAnalyzing
               ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
               : 'bg-blue-500 hover:bg-blue-600 text-white'
           }`}
         >
           {isAnalyzing ? (
             <>
               <i className="fa-solid fa-spinner fa-spin mr-2"></i>
               Analyzing...
             </>
           ) : (
             <>
               <i className="fa-solid fa-sync-alt mr-2"></i>
               Refresh Analysis
             </>
           )}
         </button>
       </div>
       
       {!aiAnalysis ? (
         <div className="text-center py-10 text-gray-500">
           <i className="fa-solid fa-lightbulb text-yellow-400 text-4xl mb-4"></i>
           <p className="mb-4">Get AI-powered insights to optimize your OTC trading strategy</p>
           <p className="text-sm">Click "Refresh Analysis" to generate market insights based on AI analysis</p>
         </div>
       ) : (
         <div className="space-y-6">
           {/* Market Trend Analysis */}
           <div>
             <h3 className="text-lg font-semibold text-gray-800 mb-3">Market Trend Analysis</h3>
             <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
               {Object.entries(aiAnalysis.analysisByPeriod).map(([period, data]) => (
                 <div key={period} className="bg-gray-50 p-4 rounded-lg">
                   <div className="flex justify-between items-center mb-2">
                     <span className="text-sm font-medium text-gray-700">{period}</span>
                     <span className={`text-sm font-bold px-2 py-1 rounded-full ${
                       data.trendDirection === 'bullish' 
                         ? 'bg-green-100 text-green-800' 
                         : 'bg-red-100 text-red-800'
                     }`}>
                       {data.trendDirection}
                     </span>
                   </div>
                   <div className="flex justify-between items-center">
                     <span className="text-sm text-gray-600">Price Change:</span>
                     <span className={`text-sm font-medium ${
                       data.priceChange >= 0 ? 'text-green-600' : 'text-red-600'
                     }`}>
                       {data.priceChange >= 0 ? '+' : ''}{data.priceChange}%
                     </span>
                   </div>
                   <div className="flex justify-between items-center mt-1">
                     <span className="text-sm text-gray-600">Recommendation:</span>
                     <span className="text-sm font-medium capitalize">{aiAnalysis.overallRecommendation}</span>
                   </div>
                 </div>
               ))}
             </div>
           </div>
           
           {/* AI Insights */}
           <div>
             <h3 className="text-lg font-semibold text-gray-800 mb-3">AI Trading Insights</h3>
             <div className="space-y-3">
               {aiAnalysis.insights.map((insight: any) => (
                 <div key={insight.id} className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
                   <p className="text-gray-800">{insight.text}</p>
                   <div className="mt-2 flex items-center text-xs text-gray-500">
                     <i className="fa-solid fa-check-circle text-green-500 mr-1"></i>
                     <span>AI Confidence: {insight.confidence}%</span>
                   </div>
                 </div>
               ))}
             </div>
           </div>
           
           {/* Risk Assessment */}
           <div>
             <h3 className="text-lg font-semibold text-gray-800 mb-3">Risk Assessment</h3>
             <div className="bg-yellow-50 p-4 rounded-lg">
               <div className="flex justify-between items-center mb-3">
                 <span className="font-medium text-gray-800">Overall Risk Level:</span>
                 <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                   aiAnalysis.riskAssessment.overallRisk === 'High' ? 'bg-red-100 text-red-800' :
                   aiAnalysis.riskAssessment.overallRisk === 'Moderate' ? 'bg-yellow-100 text-yellow-800' :
                   'bg-green-100 text-green-800'
                 }`}>
                   {aiAnalysis.riskAssessment.overallRisk}
                 </span>
               </div>
               <div className="space-y-2">
                 {aiAnalysis.riskAssessment.factors.map((factor: any, index: number) => (
                   <div key={index}>
                     <div className="flex justify-between text-sm mb-1">
                       <span className="text-gray-700">{factor.name}</span>
                       <span className="text-gray-500">{factor.score.toFixed(1)}/{factor.maxScore}</span>
                     </div>
                     <div className="w-full bg-gray-200 rounded-full h-2">
                       <div 
                         className="h-2 rounded-full" 
                         style={{ 
                           width: `${(factor.score / factor.maxScore) * 100}%`,
                           backgroundColor: factor.score > 7 ? '#ef4444' : 
                                          factor.score > 4 ? '#f59e0b' : '#22c55e'
                         }}
                       ></div>
                     </div>
                   </div>
                 ))}
               </div>
             </div>
           </div>
           
           {/* Optimization Recommendations */}
           <div>
             <h3 className="text-lg font-semibold text-gray-800 mb-3">Trading Optimization</h3>
             <div className="space-y-4">
               {aiAnalysis.optimizationRecommendations.map((rec: any, index: number) => (
                 <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
                   <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
                     <span className="font-medium text-gray-900 capitalize">{rec.category} optimization</span>
                   </div>
                   <div className="p-4">
                     <p className="text-gray-800 mb-1">{rec.suggestion}</p>
                     <p className="text-sm text-green-600 flex items-center">
                       <i className="fa-solid fa-chart-line mr-1"></i>
                       {rec.potentialImpact}
                     </p>
                   </div>
                 </div>
               ))}
             </div>
           </div>
         </div>
       )}
     </div>
     
     {/* AI Price Prediction */}
     {aiPricePrediction && (
       <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
         <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
           <i className="fa-solid fa-chart-line text-purple-500 mr-2"></i>
           AI Price Prediction: {aiPricePrediction.pair}
         </h2>
         
         <div className="mb-6">
           <div className="flex justify-between items-center mb-2">
             <span className="text-gray-700">Current Price:</span>
             <span className="text-xl font-bold text-gray-900">${aiPricePrediction.currentPrice}</span>
           </div>
           <div className="flex justify-between items-center">
             <span className="text-gray-700">72-hour Price Target:</span>
             <span className={`text-xl font-bold ${
               aiPricePrediction.predictionPoints[5].price > aiPricePrediction.currentPrice 
                 ? 'text-green-600' 
                 : 'text-red-600'
             }`}>
               ${aiPricePrediction.predictionPoints[5].price}
             </span>
           </div>
         </div>
         
         <div className="h-64">
           {/* This would be a chart component in a real implementation */}
           <div className="flex items-end justify-between h-full gap-2 px-2">
             {aiPricePrediction.predictionPoints.map((point: any) => (
               <div key={point.hours} className="flex flex-col items-center w-full">
                 <div 
                   className="w-full rounded-t-lg" 
                   style={{ 
                     height: `${Math.max(30, (point.price / Math.max(...aiPricePrediction.predictionPoints.map((p: any) => p.price))) * 200)}px`,
                     backgroundColor: point.trend === 'up' ? '#10b981' : point.trend === 'down' ? '#ef4444' : '#6b7280'
                   }}
                 ></div>
                 <div className="mt-2 text-center">
                   <div className="text-sm font-medium text-gray-900">${point.price}</div>
                   <div className="text-xs text-gray-500">{point.hours}h</div>
                 </div>
               </div>
             ))}
           </div>
         </div>
         
         <div className="mt-4 text-center">
           <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
             <i className="fa-solid fa-check-circle mr-1"></i>
             Prediction confidence: {aiPricePrediction.confidenceScore * 100}%
           </span>
         </div>
       </div>
     )}
     
     {/* Order Book AI Analysis */}
     {aiOrderBookAnalysis && (
       <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
         <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
           <i className="fa-solid fa-book-open text-indigo-500 mr-2"></i>
           AI Order Book Analysis
         </h2>
         
         <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
           <div>
             <h3 className="text-lg font-semibold text-gray-800 mb-3">Key Levels</h3>
             <div className="space-y-4">
               <div className="bg-green-50 p-4 rounded-lg">
                 <span className="text-sm text-gray-500 block mb-1">Support Level</span>
                 <span className="text-xl font-bold text-green-700">${aiOrderBookAnalysis.supportLevel}</span>
               </div>
               <div className="bg-red-50 p-4 rounded-lg">
                 <span className="text-sm text-gray-500 block mb-1">Resistance Level</span>
                 <span className="text-xl font-bold text-red-700">${aiOrderBookAnalysis.resistanceLevel}</span>
               </div>
             </div>
           </div>
           
           <div>
             <h3 className="text-lg font-semibold text-gray-800 mb-3">Optimal Prices</h3>
             <div className="space-y-4">
               <div className="bg-blue-50 p-4 rounded-lg">
                 <span className="text-sm text-gray-500 block mb-1">Recommended Buy Price</span>
                 <span className="text-xl font-bold text-blue-700">${aiOrderBookAnalysis.optimalBuyPrice}</span>
               </div>
               <div className="bg-purple-50 p-4 rounded-lg">
                 <span className="text-sm text-gray-500 block mb-1">Recommended Sell Price</span>
                 <span className="text-xl font-bold text-purple-700">${aiOrderBookAnalysis.optimalSellPrice}</span>
               </div>
             </div>
           </div>
         </div>
         
         <div className="mb-6">
           <h3 className="text-lg font-semibold text-gray-800 mb-3">Market Structure</h3>
           <div className="grid grid-cols-3 gap-4 text-center">
             <div className="border border-gray-200 rounded-lg p-4">
               <div className="text-2xl font-bold text-gray-900">{aiOrderBookAnalysis.orderDistribution.buyOrders}</div>
               <div className="text-sm text-gray-500">Buy Orders</div>
             </div>
             <div className="border border-gray-200 rounded-lg p-4">
               <div className="text-2xl font-bold text-gray-900">{aiOrderBookAnalysis.orderDistribution.sellOrders}</div>
               <div className="text-sm text-gray-500">Sell Orders</div>
             </div>
             <div className="border border-gray-200 rounded-lg p-4">
               <div className="text-2xl font-bold text-gray-900">{aiOrderBookAnalysis.orderDistribution.buySellRatio}</div>
               <div className="text-sm text-gray-500">Buy/Sell Ratio</div>
             </div>
           </div>
         </div>
         
         <div>
           <h3 className="text-lg font-semibold text-gray-800 mb-3">Liquidity Assessment</h3>
           <div className="bg-gray-50 p-4 rounded-lg">
             <div className="flex justify-between items-center mb-2">
               <span className="font-medium text-gray-900">Liquidity Score</span>
               <span className="text-lg font-bold text-gray-900">{aiOrderBookAnalysis.liquidityScore}/100</span>
             </div>
             <div className="w-full bg-gray-200 rounded-full h-2.5 mb-3">
               <div 
                 className="h-2.5 rounded-full" 
                 style={{ 
                   width: `${aiOrderBookAnalysis.liquidityScore}%`,
                   backgroundColor: aiOrderBookAnalysis.liquidityScore > 70 ? '#10b981' : 
                                  aiOrderBookAnalysis.liquidityScore > 40 ? '#f59e0b' : '#ef4444'
                 }}
               ></div>
             </div>
             <p className="text-sm text-gray-700">{aiOrderBookAnalysis.liquidityRecommendation}</p>
           </div>
         </div>
       </div>
     )}
     
    </div>
  );
}