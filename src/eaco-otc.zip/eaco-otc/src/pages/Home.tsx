import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Navbar } from '@/components/layout/Navbar';

export default function Home() {
  const { t } = useTranslation();
  
  // Features data
  const features = [
    {
      title: "Decentralized Exchange",
      description: "Secure peer-to-peer exchanges with EACO as the intermediary currency",
      icon: "fa-exchange-alt"
    },
    {
      title: "Multi-Currency Support",
      description: "Exchange between USDC, USDT, SOL and EACO with competitive rates",
      icon: "fa-coins"
    },
    {
      title: "Secure Wallet Integration",
      description: "Connect with Phantom and other Solana wallets for secure transactions",
      icon: "fa-wallet"
    },
    {
      title: "Global Community",
      description: "Join our international community with multi-language support",
      icon: "fa-globe"
    }
  ];
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <Navbar />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 md:pr-12">
                <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight">
                  EACO: The Global <span className="text-blue-600">Value Mediator</span>
                </h1>
                <p className="mt-6 text-xl text-gray-600">
                  Connecting global users through secure, decentralized digital asset exchange with EACO as the intermediary currency.
                </p>
                <div className="mt-8 flex space-x-4">
                  <Link 
                    to="/exchange"
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg shadow-md transition-colors"
                  >
                    Start Exchange
                    <i className="fa-solid fa-arrow-right ml-2"></i>
                  </Link>
                  <Link
                    to="/help"
                    className="px-6 py-3 bg-white hover:bg-gray-50 text-blue-600 font-medium rounded-lg shadow-md border border-gray-200 transition-colors"
                  >
                    Learn More
                  </Link>
                </div>
              </div>
              <div className="md:w-1/2 mt-12 md:mt-0">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Global%20digital%20currency%20exchange%20platform%2C%20modern%20UI%2C%20blue%20color%20scheme&sign=3a386272dc1549a57b9fe51bedadb793" 
                  alt="EACO Exchange Platform" 
                  className="rounded-xl shadow-xl w-full object-cover h-80 md:h-96"
                />
              </div>
            </div>
          </div>
        </section>
        
        {/* Features Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900">Powerful Exchange Features</h2>
              <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
                Built for global users with security, speed, and accessibility in mind
              </p>
            </div>
            
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <div key={index} className="bg-gray-50 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 mb-4">
                    <i className={`fa-solid ${feature.icon} text-xl`}></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-blue-600 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold mb-4">Join the Global EACO Community</h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8">
              Become part of a decentralized financial ecosystem connecting users worldwide through secure digital asset exchange.
            </p>
            <Link
              to="/exchange"
              className="px-8 py-4 bg-white text-blue-600 font-bold rounded-lg shadow-lg hover:bg-blue-50 transition-colors text-lg"
            >
              Start Exchanging Now
            </Link>
          </div>
        </section>
      </main>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=EACO%20logo%2C%20white%20on%20blue%20background&sign=b01656e24c3b08971eaa1d66961412d4" 
                  alt="EACO Logo" 
                  className="h-8 w-8 rounded-full"
                />
                <span className="ml-2 text-xl font-bold">EACO</span>
              </div>
              <p className="mt-4 text-gray-400">
                Earth's Best Coin - Connecting global users through decentralized value exchange.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Platform</h3>
              <ul className="space-y-2">
                <li><Link to="/exchange" className="text-gray-400 hover:text-white transition-colors">Exchange</Link></li>
                <li><Link to="/history" className="text-gray-400 hover:text-white transition-colors">Transaction History</Link></li>
                <li><Link to="/help" className="text-gray-400 hover:text-white transition-colors">Help Center</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Documentation</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">API</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Community</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Connect</h3>
              <ul className="space-y-2">
    <li><a href="https://t.me/e_eacocc" className="text-gray-400 hover:text-white transition-colors">Telegram</a></li>
    <li><a href="https://x.com/eacocc" className="text-gray-400 hover:text-white transition-colors">Twitter</a></li>
    <li><a href="https://github.com/eacocc/EACO_Exchange_DApp" className="text-gray-400 hover:text-white transition-colors">GitHub</a></li>
    <li><a href="https://linktr.ee/eacocc" className="text-gray-400 hover:text-white transition-colors">Linktree</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400">
               <p>&copy; {new Date().getFullYear()} EACO.OTC group All rights reserved. | EACO OTC v0.000000001</p>
          </div>
        </div>
      </footer>
    </div>
  );
}