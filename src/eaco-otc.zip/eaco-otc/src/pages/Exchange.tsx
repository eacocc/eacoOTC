import { Navbar } from '@/components/layout/Navbar';
import { ExchangeForm } from '@/components/exchange/ExchangeForm';
import { WalletProvider } from '@solana/wallet-adapter-react';
import { PhantomWalletAdapter } from '@solana/wallet-adapter-phantom';
import { useEffect } from 'react';

export default function ExchangePage() {
  // Set up wallet adapters
  const wallets = [new PhantomWalletAdapter()];

  useEffect(() => {
    // Buffer is already available globally from main.tsx
    console.log('Buffer is available:', typeof window.Buffer !== 'undefined');
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <WalletProvider wallets={wallets} autoConnect>
            <div className="py-8">
              <ExchangeForm />
            </div>
          </WalletProvider>
        </div>
      </main>
    </div>
  );
}