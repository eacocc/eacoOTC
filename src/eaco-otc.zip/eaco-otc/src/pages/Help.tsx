import { Navbar } from '@/components/layout/Navbar';
import { useTranslation } from 'react-i18next';
import { useState } from 'react';

export default function HelpPage() {
  const { t } = useTranslation();
  const [activeSection, setActiveSection] = useState('getting_started');
  
  // Help sections with translated content
  const helpSections = [
    {
      id: 'getting_started',
      title: t('help.getting_started.title'),
      content: t('help.getting_started.content'),
      faqs: [
        {
          question: t('help.getting_started.faq1.q'),
          answer: t('help.getting_started.faq1.a')
        },
        {
          question: t('help.getting_started.faq2.q'),
          answer: t('help.getting_started.faq2.a')
        },
        {
          question: t('help.getting_started.faq3.q'),
          answer: t('help.getting_started.faq3.a')
        }
      ]
    },
    {
      id: 'wallet_setup',
      title: t('help.wallet_setup.title'),
      content: t('help.wallet_setup.content'),
      faqs: [
        {
          question: t('help.wallet_setup.faq1.q'),
          answer: t('help.wallet_setup.faq1.a')
        },
        {
          question: t('help.wallet_setup.faq2.q'),
          answer: t('help.wallet_setup.faq2.a')
        }
      ]
    },
    {
      id: 'otc_trading',
      title: t('help.otc_trading.title'),
      content: t('help.otc_trading.content'),
      steps: [
        {
          title: t('help.otc_trading.steps.step1.title'),
          description: t('help.otc_trading.steps.step1.description')
        },
        {
          title: t('help.otc_trading.steps.step2.title'),
          description: t('help.otc_trading.steps.step2.description')
        },
        {
          title: t('help.otc_trading.steps.step3.title'),
          description: t('help.otc_trading.steps.step3.description')
        },
        {
          title: t('help.otc_trading.steps.step4.title'),
          description: t('help.otc_trading.steps.step4.description')
        },
        {
          title: t('help.otc_trading.steps.step5.title'),
          description: t('help.otc_trading.steps.step5.description')
        }
      ],
      faqs: [
        {
          question: t('help.otc_trading.faq1.q'),
          answer: t('help.otc_trading.faq1.a')
        },
        {
          question: t('help.otc_trading.faq2.q'),
          answer: t('help.otc_trading.faq2.a')
        },
        {
          question: t('help.otc_trading.faq3.q'),
          answer: t('help.otc_trading.faq3.a')
        },
        {
          question: t('help.otc_trading.faq4.q'),
          answer: t('help.otc_trading.faq4.a')
        },
        {
          question: t('help.otc_trading.faq5.q'),
          answer: t('help.otc_trading.faq5.a')
        }
      ]
    },
    {
      id: 'fees',
      title: t('help.fees.title'),
      content: t('help.fees.content'),
      faqs: [
        {
          question: t('help.fees.faq1.q'),
          answer: t('help.fees.faq1.a')
        },
        {
          question: t('help.fees.faq2.q'),
          answer: t('help.fees.faq2.a')
        }
      ]
    },
    {
      id: 'security',
      title: t('help.security.title'),
      content: t('help.security.content'),
      faqs: [
        {
          question: t('help.security.faq1.q'),
          answer: t('help.security.faq1.a')
        },
        {
          question: t('help.security.faq2.q'),
          answer: t('help.security.faq2.a')
        }
      ]
    },
    {
      id: 'disputes',
      title: t('help.disputes.title'),
      content: t('help.disputes.content'),
      faqs: [
        {
          question: t('help.disputes.faq1.q'),
          answer: t('help.disputes.faq1.a')
        },
        {
          question: t('help.disputes.faq2.q'),
          answer: t('help.disputes.faq2.a')
        }
      ]
    }
  ];
  
  // Regional support contacts
  const regionalSupport = [
    {
      region: t('help.support.regions.north_america'),
      email: 'eaco2cc@gmail.com',
      languages: t('help.support.languages.english')
    },
    {
      region: t('help.support.regions.europe'),
      email: 'eaco2cc@gmail.com',
      languages: t('help.support.languages.english_french_german')
    },
    {
      region: t('help.support.regions.asia'),
      email: 'eaco2cc@gmail.com',
      languages: t('help.support.languages.chinese_japanese_korean')
    },
    {
      region: t('help.support.regions.southeast_asia'),
      email: 'eaco2cc@gmail.com',
      languages: t('help.support.languages.english_vietnamese_indonesian')
    },
    {
      region: t('help.support.regions.latin_america'),
      email: 'eaco2cc@gmail.com',
      languages: t('help.support.languages.spanish_portuguese')
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">{t('navbar.help')}</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar navigation */}
            <div className="lg:col-span-1">
              <div className="bg-white shadow rounded-lg overflow-hidden sticky top-6">
                <nav className="p-4">
                  <ul className="space-y-1">
                    {helpSections.map(section => (
                      <li key={section.id}>
                        <button
                          onClick={() => setActiveSection(section.id)}
                          className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                            activeSection === section.id
                              ? 'bg-blue-50 text-blue-700'
                              : 'text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          {section.title}
                        </button>
                      </li>
                    ))}
                    <li>
                      <button
                        onClick={() => setActiveSection('support')}
                        className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                          activeSection === 'support'
                            ? 'bg-blue-50 text-blue-700'
                            : 'text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {t('help.support.title')}
                      </button>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
            
            {/* Main content */}
            <div className="lg:col-span-3">
              {activeSection !== 'support' ? (
                helpSections.map(section => (
                  section.id === activeSection && (
                    <div key={section.id} className="bg-white shadow-md rounded-lg overflow-hidden">
                      <div className="px-6 py-4 border-b border-gray-200">
                        <h2 className="text-2xl font-semibold text-gray-800">{section.title}</h2>
                      </div>
                      
                      <div className="px-6 py-6">
                        <div className="prose max-w-none text-gray-700">
                          <p>{section.content}</p>
                        </div>
                        
                        <div className="mt-8">
                          <h3 className="text-lg font-medium text-gray-900 mb-4">{t('help.faq')}</h3>
                          
                          <div className="space-y-4">
                            {section.faqs.map((faq, index) => (
                              <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
                                <div className="px-4 py-3 bg-gray-50">
                                  <h4 className="font-medium text-gray-900">{faq.question}</h4>
                                </div>
                                <div className="px-4 py-3">
                                  <p className="text-gray-700">{faq.answer}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                           
                          {/* 全球OTC交易教程与指南 */}
                          <div className="mt-12 pt-8 border-t border-gray-200">
                            <h3 className="text-2xl font-bold text-gray-800 mb-6">OTC交易完整教程</h3>
                            <p className="text-gray-700 mb-8">本教程将指导您完成通过OTC方式兑换EACO的全过程，包括法币通道选择、流动性池使用、钱包设置等关键步骤。</p>
                           
                            <div className="space-y-10">
                              {/* 法币通道与本地支付网关 */}
                              <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
                                <div className="flex items-center mb-4">
                                  <div className="bg-blue-100 p-3 rounded-full mr-4">
                                    <i className="fa-solid fa-university text-blue-600 text-xl"></i>
                                  </div>
                                  <h4 className="text-xl font-semibold text-gray-800">1. 法币通道与本地支付网关</h4>
                                </div>
                                
                                <p className="text-gray-700 mb-4">全球前10种法定货币可通过当地中介或支付网关与EACO进行兑换。不同的法币可以通过地区性合作伙伴或平台支持，确保兑换流畅。</p>
                                
                                <h5 className="font-medium text-gray-900 mb-3">主流法币与推荐支付方式</h5>
                                <div className="overflow-x-auto mb-4">
                                  <table className="min-w-full border border-gray-200 rounded-lg">
                                    <thead>
                                      <tr className="bg-gray-50">
                                        <th className="py-2 px-4 border-b text-left">排名</th>
                                        <th className="py-2 px-4 border-b text-left">货币名称</th>
                                        <th className="py-2 px-4 border-b text-left">推荐支付网关</th>
                                        <th className="py-2 px-4 border-b text-left">处理时间</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr className="hover:bg-gray-50">
                                        <td className="py-3 px-4 border-b">1</td>
                                        <td className="py-3 px-4 border-b font-medium">USD</td>
                                        <td className="py-3 px-4 border-b">MoonPay, Paxful, LocalBitcoins</td>
                                        <td className="py-3 px-4 border-b">10-30分钟</td>
                                      </tr>
                                      <tr className="hover:bg-gray-50">
                                        <td className="py-3 px-4 border-b">2</td>
                                        <td className="py-3 px-4 border-b font-medium">EUR</td>
                                        <td className="py-3 px-4 border-b">Ramp Network, Binance P2P</td>
                                        <td className="py-3 px-4 border-b">15-45分钟</td>
                                      </tr>
                                      <tr className="hover:bg-gray-50">
                                        <td className="py-3 px-4 border-b">3</td>
                                        <td className="py-3 px-4 border-b font-medium">CNH</td>
                                        <td className="py-3 px-4 border-b">火币OTC, 币安C2C</td>
                                        <td className="py-3 px-4 border-b">5-20分钟</td>
                                      </tr>
                                      <tr className="hover:bg-gray-50">
                                        <td className="py-3 px-4 border-b">4-10</td>
                                        <td className="py-3 px-4 border-b font-medium">GBP/JPY/CHF等</td>
                                        <td className="py-3 px-4 border-b">Transak, Skrill OTC</td>
                                        <td className="py-3 px-4 border-b">20-60分钟</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div>
                                
                                <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                                  <h5 className="font-medium text-blue-800 mb-2">支付网关集成选项</h5>
                                  <ul className="list-disc pl-5 text-blue-700 space-y-1">
                                    <li>国际: PayPal, Stripe, MoonPay, Ramp</li>
                                    <li>亚洲: Alipay, WeChat Pay, UnionPay</li>
                                    <li>美洲: Square, PayPal, Venmo</li>
                                    <li>欧洲: SEPA转账, Revolut, Skrill</li>
                                  </ul>
                                </div>
                              </div>
                              
                              {/* EACO与稳定币流动性池 */}
                              <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
                                <div className="flex items-center mb-4">
                                  <div className="bg-green-100 p-3 rounded-full mr-4">
                                    <i className="fa-solid fa-link text-green-600 text-xl"></i>
                                  </div>
                                  <h4 className="text-xl font-semibold text-gray-800">2. EACO与稳定币流动性池</h4>
                                </div>
                                
                                <p className="text-gray-700 mb-4">EACO兑换池可通过不同平台的流动性池进行连接，以保证法币对EACO的兑换有充足的流动性。以下是主要的流动性池及其特点：</p>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                  <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                                    <h5 className="font-medium text-gray-900 mb-2">USDT池</h5>
                                    <p className="text-sm text-gray-600 mb-2">提供EACO与USDT的兑换通道</p>
                                    <a href="https://app.meteora.ag/dlmm/6ZfCi3qzhgDN1ygHVYXvfsfrwz8ZhQ7hD5mJtjeuUDyE" className="text-blue-600 text-sm hover:underline flex items-center">
                                      访问池 <i className="fa-solid fa-external-link ml-1 text-xs"></i>
                                    </a>
                                  </div>
                                  <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                                    <h5 className="font-medium text-gray-900 mb-2">USDC池</h5>
                                    <p className="text-sm text-gray-600 mb-2">提供EACO与USDC的兑换通道</p>
                                    <a href="https://www.orca.so/pools/Cm6EkxcYNfvxeYDBQ3TGXFqa9NCWvrFKHz4Cfju91dhr" className="text-blue-600 text-sm hover:underline flex items-center">
                                      访问池 <i className="fa-solid fa-external-link ml-1 text-xs"></i>
                                    </a>
                                  </div>
                                  <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                                    <h5 className="font-medium text-gray-900 mb-2">SOL池</h5>
                                    <p className="text-sm text-gray-600 mb-2">提供EACO与SOL的兑换通道</p>
                                    <a href="https://raydium.io/liquidity-pools/?token=DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH" className="text-blue-600 text-sm hover:underline flex items-center">
                                      访问池 <i className="fa-solid fa-external-link ml-1 text-xs"></i>
                                    </a>
                                  </div>
                                  <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                                    <h5 className="font-medium text-gray-900 mb-2">多币种池</h5>
                                    <p className="text-sm text-gray-600 mb-2">USDC/USDT/SOL混合池</p>
                                    <a href="https://www.orca.so/pools?tokens=DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH" className="text-blue-600 text-sm hover:underline flex items-center">
                                      访问池 <i className="fa-solid fa-external-link ml-1 text-xs"></i>
                                    </a>
                                  </div>
                                </div>
                              </div>
                              
                              {/* 区块链基础设施 */}
                              <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
                                <div className="flex items-center mb-4">
                                  <div className="bg-purple-100 p-3 rounded-full mr-4">
                                    <i className="fa-solid fa-link text-purple-600 text-xl"></i>
                                  </div>
                                  <h4 className="text-xl font-semibold text-gray-800">3. 区块链基础设施与钱包设置</h4>
                                </div>
                                
                                <p className="text-gray-700 mb-6">EACO代币基于Solana区块链，可在Raydium和Orca等去中心化交易平台的流动性池中进行交易。为确保全球OTC交易流畅，请按照以下步骤设置您的钱包：</p>
                                
                                <div className="space-y-4 mb-6">
                                  <div className="flex">
                                    <div className="bg-gray-100 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5 mr-4 font-medium text-gray-700">1</div>
                                    <div>
                                      <h5 className="font-medium text-gray-900">下载并安装Phantom钱包</h5>
                                      <p className="text-gray-600">访问<a href="https://phantom.app" className="text-blue-600 hover:underline">phantom.app</a>下载官方钱包，支持Chrome、Firefox、Brave等浏览器扩展，以及iOS和Android移动应用。</p>
                                    </div>
                                  </div>
                                  <div className="flex">
                                    <div className="bg-gray-100 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5 mr-4 font-medium text-gray-700">2</div>
                                    <div>
                                      <h5 className="font-medium text-gray-900">创建或导入钱包</h5>
                                      <p className="text-gray-600">按照指引创建新钱包或导入现有钱包，务必妥善保存助记词，请勿分享给任何人。</p>
                                    </div>
                                  </div>
                                  <div className="flex">
                                    <div className="bg-gray-100 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5 mr-4 font-medium text-gray-700">3</div>
                                    <div>
                                      <h5 className="font-medium text-gray-900">连接到EACO平台</h5>
                                      <p className="text-gray-600">在EACO平台点击"连接钱包"按钮，选择Phantom钱包并授权连接。</p>
                                    </div>
                                  </div>
                                  <div className="flex">
                                    <div className="bg-gray-100 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5 mr-4 font-medium text-gray-700">4</div>
                                    <div>
                                      <h5 className="font-medium text-gray-900">添加EACO代币</h5>
                                      <p className="text-gray-600">在Phantom钱包中点击"添加代币"，输入EACO合约地址：<code className="bg-gray-100 px-2 py-1 rounded text-sm">DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH</code></p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              
                              {/* EACO社区与生态链接 */}
                              <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
                                <div className="flex items-center mb-4">
                                  <div className="bg-amber-100 p-3 rounded-full mr-4">
                                    <i className="fa-solid fa-users text-amber-600 text-xl"></i>
                                  </div>
                                  <h4 className="text-xl font-semibold text-gray-800">4. EACO社区与生态链接</h4>
                                </div>
                                
                                <p className="text-gray-700 mb-6">通过EACO社区平台获取支持，加入对应语言和地区的社群，获取实时帮助和最新资讯：</p>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="flex items-start p-3 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i className="fa-brands fa-telegram text-blue-500 text-xl mt-0.5 mr-3"></i>
                                    <div>
                                      <h5 className="font-medium text-gray-900">国际英文社区</h5>
                                      <a href="https://t.me/e_eacocc" className="text-blue-600 hover:underline text-sm">https://t.me/e_eacocc</a>
                                    </div>
                                  </div>
                                  <div className="flex items-start p-3 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i className="fa-brands fa-telegram text-blue-500 text-xl mt-0.5 mr-3"></i>
                                    <div>
                                      <h5 className="font-medium text-gray-900">华语社区</h5>
                                      <a href="https://t.me/aieaco" className="text-blue-600 hover:underline text-sm">https://t.me/aieaco</a>
                                    </div>
                                  </div>
                                  <div className="flex items-start p-3 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i className="fa-brands fa-telegram text-blue-500 text-xl mt-0.5 mr-3"></i>
                                    <div>
                                      <h5 className="font-medium text-gray-900">西班牙语社区</h5>
                                      <a href="https://t.me/eacoespanish" className="text-blue-600 hover:underline text-sm">https://t.me/eacoespanish</a>
                                    </div>
                                  </div>
                                  <div className="flex items-start p-3 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i className="fa-brands fa-telegram text-blue-500 text-xl mt-0.5 mr-3"></i>
                                    <div>
                                      <h5 className="font-medium text-gray-900">越南语社区</h5>
                                      <a href="https://t.me/e_vietnam" className="text-blue-600 hover:underline text-sm">https://t.me/e_vietnam</a>
                                    </div>
                                  </div>
                                  <div className="flex items-start p-3 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i className="fa-brands fa-telegram text-blue-500 text-xl mt-0.5 mr-3"></i>
                                    <div>
                                      <h5 className="font-medium text-gray-900">印尼语社区</h5>
                                      <a href="https://t.me/e_indonesia" className="text-blue-600 hover:underline text-sm">https://t.me/e_indonesia</a>
                                    </div>
                                  </div>
                                  <div className="flex items-start p-3 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i className="fa-brands fa-github text-gray-800 text-xl mt-0.5 mr-3"></i>
                                    <div>
                                      <h5 className="font-medium text-gray-900">E swap代码库</h5>
                                      <a href="https://github.com/eacocc/EACO_Exchange_DApp" className="text-blue-600 hover:underline text-sm">github.com/eacocc/EACO_Exchange_DApp</a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              
                              {/* 兑换流程总结 */}
                              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100">
                                <h4 className="text-xl font-semibold text-gray-800 mb-4">OTC兑换完整流程</h4>
                                <div className="flex flex-col md:flex-row items-center justify-between">
                                  <div className="text-center md:text-left mb-6 md:mb-0 md:mr-6">
                                    <p className="text-gray-700 font-medium">法币 → 稳定币 → EACO</p>
                                    <p className="text-sm text-gray-500 mt-1">安全、快捷的全球兑换通道</p>
                                  </div>
                                  <div className="flex items-center justify-center flex-1">
                                    <div className="flex items-center w-full max-w-md">
                                      <div className="flex-1 text-center">
                                        <div className="bg-white rounded-full w-16 h-16 flex items-center justify-center shadow-md mx-auto mb-2">
                                          <i className="fa-solid fa-money-bill text-green-600 text-2xl"></i>
                                        </div>
                                        <p className="text-sm font-medium">法币</p>
                                        <p className="text-xs text-gray-500">USD/EUR/CNH等</p>
                                      </div>
                                      <div className="text-blue-500 text-xl mx-2">→</div>
                                      <div className="flex-1 text-center">
                                        <div className="bg-white rounded-full w-16 h-16 flex items-center justify-center shadow-md mx-auto mb-2">
                                          <i className="fa-solid fa-coins text-blue-600 text-2xl"></i>
                                        </div>
                                        <p className="text-sm font-medium">稳定币</p>
                                        <p className="text-xs text-gray-500">USDT/USDC/SOL</p>
                                      </div>
                                      <div className="text-blue-500 text-xl mx-2">→</div>
                                      <div className="flex-1 text-center">
                                        <div className="bg-white rounded-full w-16 h-16 flex items-center justify-center shadow-md mx-auto mb-2">
                                          <i className="fa-solid fa-cube text-purple-600 text-2xl"></i>
                                        </div>
                                        <p className="text-sm font-medium">EACO</p>
                                        <p className="text-xs text-gray-500">$e = $eaco</p>
               </div>
             </div>
           </div>
         </div>
         
         {/* AI-Powered Trading Section */}
         <div className="mt-12 pt-8 border-t border-gray-200">
           <h3 className="text-2xl font-bold text-gray-800 mb-6">AI-Powered OTC Trading</h3>
           <p className="text-gray-700 mb-8">Our platform leverages advanced AI technology to analyze market conditions and provide personalized trading recommendations, helping you make more informed decisions in your OTC transactions.</p>
           
           <div className="space-y-10">
             {/* AI Analysis Features */}
             <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
               <div className="flex items-center mb-4">
                 <div className="bg-blue-100 p-3 rounded-full mr-4">
                   <i className="fa-solid fa-microchip text-blue-600 text-xl"></i>
                 </div>
                 <h4 className="text-xl font-semibold text-gray-800">AI Market Analysis</h4>
               </div>
               
               <p className="text-gray-700 mb-6">Our AI system continuously analyzes market conditions, trading patterns, and global economic indicators to provide real-time insights for OTC traders.</p>
               
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div className="flex items-start p-3 border border-gray-100 rounded-lg">
                   <i className="fa-solid fa-chart-line text-green-500 text-xl mt-0.5 mr-3"></i>
                   <div>
                     <h5 className="font-medium text-gray-900">Market Trend Prediction</h5>
                     <p className="text-sm text-gray-600">AI-powered forecasts for EACO price movements across different time horizons (24h, 7d, 30d)</p>
                   </div>
                 </div>
                 <div className="flex items-start p-3 border border-gray-100 rounded-lg">
                   <i className="fa-solid fa-lightbulb text-yellow-500 text-xl mt-0.5 mr-3"></i>
                   <div>
                     <h5 className="font-medium text-gray-900">Trading Insights</h5>
                     <p className="text-sm text-gray-600">Actionable recommendations based on pattern recognition and market sentiment analysis</p>
                   </div>
                 </div>
                 <div className="flex items-start p-3 border border-gray-100 rounded-lg">
                   <i className="fa-solid fa-shield-alt text-red-500 text-xl mt-0.5 mr-3"></i>
                   <div>
                     <h5 className="font-medium text-gray-900">Risk Assessment</h5>
                     <p className="text-sm text-gray-600">Comprehensive risk evaluation for different trading strategies and market conditions</p>
                   </div>
                 </div>
                 <div className="flex items-start p-3 border border-gray-100 rounded-lg">
                   <i className="fa-solid fa-cogs text-purple-500 text-xl mt-0.5 mr-3"></i>
                   <div>
                     <h5 className="font-medium text-gray-900">Trading Optimization</h5>
                     <p className="text-sm text-gray-600">Personalized suggestions to improve trading performance and profitability</p>
                   </div>
                 </div>
               </div>
             </div>
             
             {/* AI Order Book Analysis */}
             <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
               <div className="flex items-center mb-4">
                 <div className="bg-purple-100 p-3 rounded-full mr-4">
                   <i className="fa-solid fa-book-open text-purple-600 text-xl"></i>
                 </div>
                 <h4 className="text-xl font-semibold text-gray-800">AI Order Book Analysis</h4>
               </div>
               
               <p className="text-gray-700 mb-6">Our AI system analyzes the OTC order book to identify key price levels, liquidity conditions, and optimal trading opportunities.</p>
               
               <div className="overflow-x-auto">
                 <table className="min-w-full border border-gray-200 rounded-lg">
                   <thead>
                     <tr className="bg-gray-50">
                       <th className="py-2 px-4 border-b text-left">Analysis Type</th>
                       <th className="py-2 px-4 border-b text-left">Description</th>
                       <th className="py-2 px-4 border-b text-left">Benefit</th>
                     </tr>
                   </thead>
                   <tbody>
                     <tr className="hover:bg-gray-50">
                       <td className="py-3 px-4 border-b font-medium">Support/Resistance Levels</td>
                       <td className="py-3 px-4 border-b">AI identifies key price levels where buying/selling pressure is concentrated</td>
                       <td className="py-3 px-4 border-b">Better entry and exit points for trades</td>
                     </tr>
                     <tr className="hover:bg-gray-50">
                       <td className="py-3 px-4 border-b font-medium">Optimal Price Recommendations</td>
                       <td className="py-3 px-4 border-b">AI suggests ideal prices based on current order book structure</td>
                       <td className="py-3 px-4 border-b">Improved order execution and profitability</td>
                     </tr>
                     <tr className="hover:bg-gray-50">
                       <td className="py-3 px-4 border-b font-medium">Liquidity Assessment</td>
                       <td className="py-3 px-4 border-b">Analysis of market depth and order distribution</td>
                       <td className="py-3 px-4 border-b">Reduced slippage and better trade execution</td>
                     </tr>
                   </tbody>
                 </table>
               </div>
             </div>
             
             {/* AI Price Prediction */}
             <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
               <div className="flex items-center mb-4">
                 <div className="bg-green-100 p-3 rounded-full mr-4">
                   <i className="fa-solid fa-chart-line text-green-600 text-xl"></i>
                 </div>
                 <h4 className="text-xl font-semibold text-gray-800">AI Price Prediction</h4>
               </div>
               
               <p className="text-gray-700 mb-6">Our AI models generate price predictions for EACO against major currencies, helping you plan your trading strategy with greater confidence.</p>
               
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 <div className="border border-gray-200 rounded-lg p-4 text-center">
                   <div className="text-3xl font-bold text-gray-900 mb-1">24h</div>
                   <div className="text-sm text-gray-500 mb-3">Short-term forecast</div>
                   <div className="flex justify-center items-center">
                     <i className="fa-solid fa-arrow-up text-green-500 mr-1"></i>
                     <span className="font-medium text-green-600">+2.4-3.8%</span>
                   </div>
                 </div>
                 <div className="border border-gray-200 rounded-lg p-4 text-center">
                   <div className="text-3xl font-bold text-gray-900 mb-1">72h</div>
                   <div className="text-sm text-gray-500 mb-3">Medium-term forecast</div>
                   <div className="flex justify-center items-center">
                     <i className="fa-solid fa-arrow-up text-green-500 mr-1"></i>
                     <span className="font-medium text-green-600">+5.1-7.3%</span>
                   </div>
                 </div>
                 <div className="border border-gray-200 rounded-lg p-4 text-center">
                   <div className="text-3xl font-bold text-gray-900 mb-1">7d</div>
                   <div className="text-sm text-gray-500 mb-3">Long-term forecast</div>
                   <div className="flex justify-center items-center">
                     <i className="fa-solid fa-arrow-up text-green-500 mr-1"></i>
                     <span className="font-medium text-green-600">+8.7-11.2%</span>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>
                            </div>
                          </div>

                          <p className="text-sm text-gray-500 italic mt-8">注：eaco OTC方案探索中，以上内容仅供参考。</p>
                        </div>
                      </div>
                    </div>
                  )
                ))
              ) : (
                <div className="bg-white shadow-md rounded-lg overflow-hidden">
                  <div className="px-6 py-4 border-b border-gray-200">
                    <h2 className="text-2xl font-semibold text-gray-800">{t('help.support.title')}</h2>
                  </div>
                  
                  <div className="px-6 py-6">
                    <p className="text-gray-700 mb-6">
                      {t('help.support.content')}
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {regionalSupport.map((region, index) => (
                        <div key={index} className="border border-gray-200 rounded-lg p-4">
                          <h3 className="font-medium text-gray-900 mb-2">{region.region}</h3>
                          <p className="text-gray-600 mb-1">
                            <i className="fa-solid fa-envelope mr-2 text-gray-400"></i>
                            {region.email}
                          </p>
                          <p className="text-gray-600 text-sm">
                            <i className="fa-solid fa-language mr-2 text-gray-400"></i>
                            {region.languages}
                          </p>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-8 bg-blue-50 border border-blue-100 rounded-lg p-4">
                      <h3 className="font-medium text-blue-800 mb-2">{t('help.support.live_chat.title')}</h3>
                      <p className="text-blue-700 mb-4">{t('help.support.live_chat.content')}</p>
                      <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
                        <i className="fa-solid fa-comments mr-2"></i>
                        {t('help.support.live_chat.button')}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}