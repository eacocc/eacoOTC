import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { OTCOrder } from '@/types/transaction';
import { SUPPORTED_CURRENCIES } from '@/types/currency';

interface OrderBookProps {
  orders: OTCOrder[];
  onOrderSelect: (order: OTCOrder) => void;
}

export function OrderBook({ orders, onOrderSelect }: OrderBookProps) {
  const { t } = useTranslation();
  const [activeType, setActiveType] = useState<'buy' | 'sell'>('buy');
  
  // Filter orders by type
  const filteredOrders = orders.filter(order => 
    order.status === 'open' && order.type === activeType
  );
  
  // Sort orders (descending for buy, ascending for sell)
  const sortedOrders = [...filteredOrders].sort((a, b) => {
    if (activeType === 'buy') {
      return b.price - a.price; // Higher buy prices first
    } else {
      return a.price - b.price; // Lower sell prices first
    }
  });

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex border-b border-gray-200 mb-4">
        <button
          onClick={() => setActiveType('buy')}
          className={`py-2 px-4 font-medium text-sm ${
            activeType === 'buy' 
              ? 'text-blue-600 border-b-2 border-blue-500' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          {t('otc.buy')}
        </button>
        <button
          onClick={() => setActiveType('sell')}
          className={`py-2 px-4 font-medium text-sm ${
            activeType === 'sell' 
              ? 'text-blue-600 border-b-2 border-blue-500' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          {t('otc.sell')}
        </button>
      </div>
      
      {sortedOrders.length === 0 ? (
        <div className="text-center py-10 text-gray-500">
          <i className="fa-solid fa-file-text-o text-3xl mb-2"></i>
          <p>{t('otc.no_orders_available')}</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <th className="px-2 py-3">{t('otc.price')}</th>
                <th className="px-2 py-3">{t('otc.amount')} ({t('otc.currency')})</th>
                <th className="px-2 py-3">{t('otc.total')} ({t('otc.fiat_currency')})</th>
                <th className="px-2 py-3">{t('otc.payment_method')}</th>
                <th className="px-2 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {sortedOrders.map((order) => (
                <tr 
                  key={order.id}
                  className="hover:bg-gray-50 cursor-pointer"
                  onClick={() => onOrderSelect(order)}
                >
                  <td className="px-2 py-3 whitespace-nowrap">
                    <div className="font-medium text-gray-900">{order.price.toFixed(2)}</div>
                  </td>
                  <td className="px-2 py-3 whitespace-nowrap">
                    <div className="text-gray-600">{order.amount.toFixed(4)}</div>
                  </td>
                  <td className="px-2 py-3 whitespace-nowrap">
                    <div className="text-gray-600">{order.total.toFixed(2)}</div>
                  </td>
                  <td className="px-2 py-3 whitespace-nowrap">
                    <div className="text-gray-600 capitalize">{order.paymentMethod.replace('_', ' ')}</div>
                  </td>
                  <td className="px-2 py-3 whitespace-nowrap text-right text-sm font-medium">
                    <button className="text-blue-600 hover:text-blue-900">
                      {t('otc.trade')}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}