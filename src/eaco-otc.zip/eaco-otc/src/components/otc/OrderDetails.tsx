import { useTranslation } from 'react-i18next';
import { OTCOrder } from '@/types/transaction';
import { SUPPORTED_CURRENCIES } from '@/types/currency';
import { useExchange } from '@/hooks/useExchange';
import { toast } from 'sonner';


interface OrderDetailsProps {
  order: OTCOrder;
  onClose: () => void;
  onMatchOrder: (order: OTCOrder) => void;
  onReleaseFunds: (orderId: string) => void;
}

export function OrderDetails({ order, onClose, onMatchOrder, onReleaseFunds }: OrderDetailsProps) {
  const { t } = useTranslation();
  const { releaseEscrow, openDispute } = useExchange();
  
  const handleConfirmPayment = (orderId: string) => {
    // In a real application, this would confirm payment and release escrow
    releaseEscrow(orderId);
    toast.success(t('otc.payment_confirmed'));
    onClose();
  };
  
  const handleOpenDispute = (orderId: string) => {
    // In a real application, this would open a dispute modal
    openDispute(orderId, 'Payment not received');
    toast.info(t('otc.dispute_opened'));
    onClose();
  };
  
  // Get status badge color
  const getStatusColor = (status: OTCOrder['status']) => {
    switch (status) {
      case 'open':
        return 'bg-green-100 text-green-800';
      case 'matched':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'disputed':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };
  
  // Get formatted payment method
  const getPaymentMethod = () => {
    const paymentMethodLabels = {
      'bank_transfer': t('otc.payment_methods.bank_transfer'),
      'mobile_money': t('otc.payment_methods.mobile_money'),
      'digital_wallet': t('otc.payment_methods.digital_wallet'),
      'cash_deposit': t('otc.payment_methods.cash_deposit')
    };
    
    return paymentMethodLabels[order.paymentMethod as keyof typeof paymentMethodLabels] || 
           order.paymentMethod.replace('_', ' ');
  };

  return (
    <div className="max-h-[90vh] overflow-y-auto">
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center sticky top-0 bg-white z-10">
        <h2 className="text-xl font-bold text-gray-800">{t('otc.order_details')}</h2>
        <button 
          onClick={onClose}
          className="text-gray-500 hover:text-gray-700"
        >
          <i className="fa-solid fa-times text-xl"></i>
        </button>
      </div>
      
      <div className="px-6 py-6">
        {/* Order Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 pb-6 border-b border-gray-200">
          <div>
            <div className="flex items-center mb-2">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)} mr-3`}>
                {t(`otc.statuses.${order.status}`)}
              </span>
              <span className="text-sm text-gray-500">#{order.id}</span>
            </div>
            <h3 className="text-2xl font-bold">
              {order.type === 'buy' ? t('otc.buy') : t('otc.sell')} {order.amount.toFixed(4)} {order.currency}
            </h3>
          </div>
          <div className="mt-4 md:mt-0 text-right">
            <p className="text-sm text-gray-500">{t('otc.created_at')}</p>
            <p className="text-sm font-medium text-gray-900">{formatDate(order.createdAt)}</p>
          </div>
        </div>
        
        {/* Order Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-3">{t('otc.price_details')}</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">{t('otc.price_per_unit')}</span>
                <span className="text-sm font-medium text-gray-900">{order.price.toFixed(2)} {order.fiatCurrency}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">{t('otc.quantity')}</span>
                <span className="text-sm font-medium text-gray-900">{order.amount.toFixed(4)} {order.currency}</span>
              </div>
              <div className="pt-2 mt-2 border-t border-gray-200 flex justify-between">
                <span className="text-sm font-medium text-gray-900">{t('otc.total')}</span>
                <span className="text-sm font-bold text-gray-900">{order.total.toFixed(2)} {order.fiatCurrency}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-500 mb-3">{t('otc.payment_details')}</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">{t('otc.payment_method')}</span>
                <span className="text-sm font-medium text-gray-900">{getPaymentMethod()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">{t('otc.fiat_currency')}</span>
                <span className="text-sm font-medium text-gray-900">{order.fiatCurrency}</span>
              </div>
              {order.status === 'matched' && order.counterparty && (
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">{t('otc.counterparty')}</span>
                  <span className="text-sm font-medium text-gray-900">
                    {order.counterparty.substring(0, 6)}...{order.counterparty.substring(order.counterparty.length - 4)}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Asset Information */}
        <div className="mb-6">
          <h4 className="text-sm font-medium text-gray-500 mb-3">{t('otc.asset_information')}</h4>
          <div className="bg-gray-50 p-4 rounded-lg flex items-center">
            <img 
              src={SUPPORTED_CURRENCIES[order.currency].icon} 
              alt={order.currency} 
              className="h-10 w-10 rounded-full mr-4"
            />
            <div>
              <div className="font-medium text-gray-900">{SUPPORTED_CURRENCIES[order.currency].name}</div>
              <div className="text-sm text-gray-500">{order.currency}</div>
            </div>
          </div>
        </div>
        
        {/* Order Timeline */}
        {order.status !== 'open' && (
          <div className="mb-6">
            <h4 className="text-sm font-medium text-gray-500 mb-3">{t('otc.order_timeline')}</h4>
            <div className="relative pl-6 border-l border-gray-200 space-y-4">
              <div className="relative">
                <div className="absolute -left-9 w-5 h-5 rounded-full bg-green-100 flex items-center justify-center">
                  <i className="fa-solid fa-check text-green-600 text-xs"></i>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{t('otc.order_created')}</p>
                  <p className="text-sm text-gray-500">{formatDate(order.createdAt)}</p>
                </div>
              </div>
              
              {order.status !== 'open' && order.matchedAt && (
                <div className="relative">
                  <div className="absolute -left-9 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center">
                    <i className="fa-solid fa-handshake text-blue-600 text-xs"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{t('otc.order_matched')}</p>
                    <p className="text-sm text-gray-500">{formatDate(order.matchedAt)}</p>
                  </div>
                </div>
              )}
              
              {order.status === 'completed' && (
                <div className="relative">
                  <div className="absolute -left-9 w-5 h-5 rounded-full bg-purple-100 flex items-center justify-center">
                    <i className="fa-solid fa-check-circle text-purple-600 text-xs"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{t('otc.order_completed')}</p>
                    <p className="text-sm text-gray-500">{formatDate(order.matchedAt || order.createdAt)}</p>
                  </div>
                </div>
              )}
              
              {order.status === 'disputed' && (
                <div className="relative">
                  <div className="absolute -left-9 w-5 h-5 rounded-full bg-yellow-100 flex items-center justify-center">
                    <i className="fa-solid fa-exclamation-triangle text-yellow-600 text-xs"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{t('otc.order_disputed')}</p>
                    <p className="text-sm text-gray-500">{formatDate(new Date().toISOString())}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t border-gray-200">
          {order.status === 'open' && (
            <button
              onClick={() => onMatchOrder(order)}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
            >
              {t('otc.take_order')}
            </button>
          )}
          
          {order.status === 'matched' && order.creator === order.counterparty && (
             <button
               onClick={() => onReleaseFunds(order.id)}
               className="flex-1 bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
               disabled={order.status === 'disputed'}
             >
               {order.status === 'disputed' ? t('otc.dispute_in_progress') : t('otc.release_funds')}
             </button>
          )}
          
          {(order.status === 'open' || order.status === 'matched') && (
            <button
              className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-3 px-4 rounded-lg transition-colors"
            >
              {t('otc.cancel_order')}
            </button>
          )}
          
           {order.status === 'matched' && (
             <>
               <button
                 className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-white font-medium py-3 px-4 rounded-lg transition-colors"
               >
                 {t('otc.open_chat')}
               </button>
               <button
                 onClick={() => handleConfirmPayment(order.id)}
                 className="flex-1 bg-green-500 hover:bg-green-600 text-white font-medium py-3 px-4 rounded-lg transition-colors"
               >
                 {t('otc.confirm_payment')}
               </button>
             </>
           )}
           
           {order.status === 'matched' || order.status === 'disputed' ? (
             <button
               onClick={() => handleOpenDispute(order.id)}
               className="flex-1 bg-red-500 hover:bg-red-600 text-white font-medium py-3 px-4 rounded-lg transition-colors"
             >
               {t('otc.open_dispute')}
             </button>
           ) : (
             <button
               disabled
               className="flex-1 bg-gray-300 text-gray-500 font-medium py-3 px-4 rounded-lg cursor-not-allowed"
             >
               {t('otc.open_dispute')}
             </button>
           )}
        </div>
      </div>
    </div>
  );
}