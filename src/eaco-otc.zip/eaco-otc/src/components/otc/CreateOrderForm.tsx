import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useExchange } from '@/hooks/useExchange';
import { Currency, SUPPORTED_CURRENCIES } from '@/types/currency';
import { useWallet } from '@/hooks/useWallet';

export function CreateOrderForm() {
  const { t } = useTranslation();
  const { currentOrder, setCurrentOrder, createOTCOrder, isLoading } = useExchange();
  const { connected } = useWallet();
  
  const [orderType, setOrderType] = useState<'buy' | 'sell'>('buy');
  const [currency, setCurrency] = useState<Currency>('EACO');
  const [fiatCurrency, setFiatCurrency] = useState('USD');
  const [amount, setAmount] = useState('');
  const [price, setPrice] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('bank_transfer');
  
  // Payment methods supported
  const paymentMethods = [
    { value: 'bank_transfer', label: t('otc.payment_methods.bank_transfer') },
    { value: 'mobile_money', label: t('otc.payment_methods.mobile_money') },
    { value: 'digital_wallet', label: t('otc.payment_methods.digital_wallet') },
    { value: 'cash_deposit', label: t('otc.payment_methods.cash_deposit') },
    { value: 'credit_card', label: t('otc.payment_methods.credit_card') },
    { value: 'debit_card', label: t('otc.payment_methods.debit_card') }
  ];
  
  // Fiat currencies commonly used with OTC trading
  const fiatCurrencies = [
    'USD', 'EUR', 'CNY', 'VND', 'IDR', 'KRW', 'JPY', 'GBP', 'AUD', 'CAD', 'BRL', 'INR', 'RUB'
  ];
  
  // Calculate total amount
  const total = amount && price ? (parseFloat(amount) * parseFloat(price)).toFixed(2) : '0.00';
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!connected) {
      alert(t('wallet.WalletNotConnectedError'));
      return;
    }
    
    if (!amount || !price) {
      alert(t('otc.missing_order_fields'));
      return;
    }
    
    // Update current order state
    setCurrentOrder({
      type: orderType,
      currency,
      fiatCurrency,
      amount: parseFloat(amount),
      price: parseFloat(price),
      paymentMethod
    });
    
    // Create the order
    createOTCOrder();
    
    // Reset form
    setAmount('');
    setPrice('');
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 sticky top-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">{t('otc.create_order')}</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Order Type */}
        <div className="flex border rounded-lg overflow-hidden">
          <button
            type="button"
            onClick={() => setOrderType('buy')}
            className={`flex-1 py-3 font-medium text-sm ${
              orderType === 'buy' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {t('otc.buy')}
          </button>
          <button
            type="button"
            onClick={() => setOrderType('sell')}
            className={`flex-1 py-3 font-medium text-sm ${
              orderType === 'sell' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {t('otc.sell')}
          </button>
        </div>
        
        {/* Currency Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {t('otc.currency')}
          </label>
          <div className="relative">
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as Currency)}
              className="block w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg bg-white focus:ring-blue-500 focus:border-blue-500 appearance-none"
            >
              {Object.values(SUPPORTED_CURRENCIES).map((c) => (
                <option key={c.symbol} value={c.symbol}>
                  {c.name} ({c.symbol})
                </option>
              ))}
            </select>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <img 
                src={SUPPORTED_CURRENCIES[currency].icon} 
                alt={currency} 
                className="h-6 w-6 rounded-full"
              />
            </div>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <i className="fa-solid fa-chevron-down text-gray-400"></i>
            </div>
          </div>
        </div>
        
        {/* Fiat Currency */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {t('otc.fiat_currency')}
          </label>
          <select
            value={fiatCurrency}
            onChange={(e) => setFiatCurrency(e.target.value)}
            className="block w-full px-4 py-3 border border-gray-300 rounded-lg bg-white focus:ring-blue-500 focus:border-blue-500"
          >
            {fiatCurrencies.map((fiat) => (
              <option key={fiat} value={fiat}>{fiat}</option>
            ))}
          </select>
        </div>
        
        {/* Amount and Price */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('otc.amount')} ({currency})
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              placeholder="0.00"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('otc.price')} ({fiatCurrency})
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              placeholder="0.00"
              required
            />
          </div>
        </div>
        
        {/* Total */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {t('otc.total')} ({fiatCurrency})
          </label>
          <input
            type="text"
            value={total}
            readOnly
            className="block w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
          />
        </div>
        
        {/* Payment Method */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {t('otc.payment_method')}
          </label>
          <select
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
            className="block w-full px-4 py-3 border border-gray-300 rounded-lg bg-white focus:ring-blue-500 focus:border-blue-500"
          >
            {paymentMethods.map(method => (
              <option key={method.value} value={method.value}>
                {method.label}
              </option>
            ))}
          </select>
        </div>
        
        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading || !connected}
          className={`w-full py-3 px-4 rounded-lg font-medium transition-colors ${
            (isLoading || !connected)
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700 text-white'
          }`}
        >
          {isLoading ? (
            <>
              <i className="fa-solid fa-spinner fa-spin mr-2"></i>
              {t('common.loading')}
            </>
          ) : (
            orderType === 'buy' ? t('otc.buy') : t('otc.sell')
          )}
        </button>
      </form>
    </div>
  );
}