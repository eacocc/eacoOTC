import { useTranslation } from 'react-i18next';
import { CurrencySelector } from './CurrencySelector';
import { useExchange } from '@/hooks/useExchange';
import { cn } from '@/lib/utils';

export function ExchangeForm() {
  const { t } = useTranslation();
  const {
    fromCurrency,
    toCurrency,
    amount,
    rate,
    estimatedAmount,
    isLoading,
    setFromCurrency,
    setToCurrency,
    setAmount,
    getRate,
    swapCurrencies,
    executeExchange
  } = useExchange();

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-md mx-auto">
      <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">{t('exchange.title')}</h2>
      
      <div className="space-y-6">
        {/* From Currency Section */}
        <div>
          <CurrencySelector
            label="exchange.from_currency"
            value={fromCurrency}
            onChange={setFromCurrency}
            disabled={isLoading}
          />
          
          <div className="mt-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('exchange.amount')}
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              disabled={isLoading}
              className="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              placeholder="0.00"
            />
          </div>
        </div>
        
        {/* Swap Button */}
        <div className="flex justify-center">
          <button
            onClick={swapCurrencies}
            disabled={isLoading}
            className="p-2 rounded-full bg-blue-100 text-blue-600 hover:bg-blue-200 transition-colors"
          >
            <i className="fa-solid fa-exchange"></i>
          </button>
        </div>
        
        {/* To Currency Section */}
        <div>
          <CurrencySelector
            label="exchange.to_currency"
            value={toCurrency}
            onChange={setToCurrency}
            disabled={isLoading}
          />
          
          {rate && (
            <div className="mt-2 p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                {t('exchange.current_rate')}: 1 {fromCurrency} = {rate.toFixed(6)} {toCurrency}
              </p>
              {estimatedAmount && (
                <p className="text-sm font-medium text-gray-800 mt-1">
                  {t('exchange.estimated_amount')}: {estimatedAmount.toFixed(6)} {toCurrency}
                </p>
              )}
            </div>
          )}
        </div>
        
        {/* Action Buttons */}
        <div className="flex space-x-3 pt-4">
          <button
            onClick={getRate}
            disabled={isLoading || !amount}
            className={cn(
              "flex-1 px-4 py-3 rounded-lg font-medium transition-colors",
              (isLoading || !amount) 
                ? "bg-gray-300 text-gray-500 cursor-not-allowed" 
                : "bg-blue-500 hover:bg-blue-600 text-white"
            )}
          >
            {isLoading ? (
              <>
                <i className="fa-solid fa-spinner fa-spin mr-2"></i>
                {t('common.loading')}
              </>
            ) : (
              t('exchange.get_rate')
            )}
          </button>
          
          <button
            onClick={executeExchange}
            disabled={isLoading || !rate || !estimatedAmount}
            className={cn(
              "flex-1 px-4 py-3 rounded-lg font-medium transition-colors",
              (isLoading || !rate || !estimatedAmount)
                ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                : "bg-green-500 hover:bg-green-600 text-white"
            )}
          >
            {t('exchange.swap_now')}
          </button>
        </div>
      </div>
    </div>
  );
}