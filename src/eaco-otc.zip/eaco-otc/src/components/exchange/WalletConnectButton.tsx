import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { cn } from '@/lib/utils';
import { useWallet } from '@/hooks/useWallet';

export function WalletConnectButton() {
  const { t } = useTranslation();
  const { connected, publicKey, connectWallet, disconnectWallet, isLoading } = useWallet();
  const [showFullAddress, setShowFullAddress] = useState(false);

  if (connected && publicKey) {
    // Format address to show first 4 and last 4 characters
    const formattedAddress = showFullAddress 
      ? publicKey 
      : `${publicKey.slice(0, 4)}...${publicKey.slice(-4)}`;

    return (
      <div className="flex items-center space-x-2">
        <div 
          className="bg-blue-100 text-blue-800 px-4 py-2 rounded-lg text-sm font-medium flex items-center cursor-pointer"
          onClick={() => setShowFullAddress(!showFullAddress)}
        >
          <i className="fa-solid fa-wallet mr-2"></i>
          <span>{formattedAddress}</span>
        </div>
        <button
          onClick={disconnectWallet}
          disabled={isLoading}
          className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
        >
          {t('exchange.disconnect')}
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={connectWallet}
      disabled={connected || isLoading}
      className={cn(
        "px-6 py-3 rounded-lg font-medium transition-colors",
        connected || isLoading 
          ? "bg-gray-400 cursor-not-allowed" 
          : "bg-blue-500 hover:bg-blue-600 text-white"
      )}
    >
      {isLoading ? (
        <>
          <i className="fa-solid fa-spinner fa-spin mr-2"></i>
          {t('common.loading')}
        </>
      ) : (
        <>
          <i className="fa-solid fa-wallet mr-2"></i>
          {t('exchange.wallet_connect')}
        </>
      )}
    </button>
  );
}