import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import i18n from '@/locales';
import { WalletConnectButton } from '../exchange/WalletConnectButton';

export function Navbar() {
  const { t } = useTranslation();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Language options
  const languages = [
    { code: 'en', name: 'English' },
    { code: 'zh', name: '中文' },
    { code: 'es', name: 'Español' },
    { code: 'vi', name: 'Tiếng Việt' }
  ];

  // Navbar links
  const navLinks = [
    { path: '/', label: 'navbar.home' },
    { path: '/exchange', label: 'navbar.exchange' },
    { path: '/history', label: 'navbar.history' },
    { path: '/otc', label: 'navbar.otc_trading' },
    { path: '/help', label: 'navbar.help' }
  ];

  // Change language handler
  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
  };

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo and desktop navigation */}
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <img 
                src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=EACO%20logo%2C%20blue%20color%2C%20modern%20design&sign=0da234f7706dee10fa0381fbdba630fc" 
                alt="EACO Logo" 
                className="h-8 w-8 rounded-full"
              />
              <span className="ml-2 text-xl font-bold text-blue-600">EACO</span>
            </Link>
            
            {/* Desktop navigation links */}
            <div className="hidden md:ml-10 md:flex md:space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`${
                    location.pathname === link.path
                      ? 'border-blue-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    link.path === '/otc' ? 'font-bold' : ''
                  }`}
                >
                  {link.path === '/otc' && (
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded-full mr-1.5">
                      {t('common.otc')}
                    </span>
                  )}
                  {t(link.label)}
                </Link>
              ))}
            </div>
          </div>
          
          {/* Right section: Language selector and wallet button */}
          <div className="flex items-center space-x-4">
            {/* Language selector */}
            <div className="relative">
              <button
                className="flex items-center text-sm border border-gray-300 rounded-md px-3 py-1.5"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                <i className="fa-solid fa-globe mr-2"></i>
                <span>{i18n.language.toUpperCase()}</span>
                <i className={`fa-solid fa-chevron-down ml-2 text-xs transition-transform ${isMenuOpen ? 'transform rotate-180' : ''}`}></i>
              </button>
              
              {isMenuOpen && (
                <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
                  <div className="py-1">
                    {languages.map((language) => (
                      <button
                        key={language.code}
                        onClick={() => {
                          changeLanguage(language.code);
                          setIsMenuOpen(false);
                        }}
                        className={`block px-4 py-2 text-sm ${
                          i18n.language === language.code
                            ? 'bg-blue-100 text-blue-600'
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        {language.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {/* Wallet connect button - desktop */}
            <div className="hidden md:block">
              <WalletConnectButton />
            </div>
            
            {/* Mobile menu button */}
            <div className="flex items-center md:hidden">
              <button
                type="button"
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none"
                aria-expanded="false"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                <i className="fa-solid fa-bars text-xl"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="pt-2 pb-3 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`${
                  location.pathname === link.path
                    ? 'bg-blue-50 border-l-4 border-blue-500 text-blue-700'
                    : 'border-l-4 border-transparent text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                } block pl-3 pr-4 py-2 text-base font-medium`}
                onClick={() => setIsMenuOpen(false)}
              >
                {t(link.label)}
              </Link>
            ))}
          </div>
          
          {/* Mobile wallet connect button */}
          <div className="pt-4 pb-3 border-t border-gray-200 px-4">
            <WalletConnectButton />
          </div>
        </div>
      )}
    </nav>
  );
}