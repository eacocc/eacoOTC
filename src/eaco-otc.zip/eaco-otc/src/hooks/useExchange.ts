import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { Currency } from '@/types/currency';
import { Transaction, OTCOrder, MOCK_OTC_ORDERS } from '@/types/transaction';
import { useWallet } from './useWallet';
import axios from 'axios';

// Fee structure - 1% for swaps, 1.5% for OTC transactions
const FEE_STRUCTURE = {
  swap: 1.0, // percentage
  otc: 1.5   // percentage
};

// DEX endpoints from project documentation
const DEX_ENDPOINTS = {
  ORCA: 'https://www.orca.so/api/v1/price',
  RAYDIUM: 'https://api.raydium.io/v2/price',
  METEORA: 'https://app.meteora.ag/api/v1/price'
};

// Token addresses from project documentation
const TOKEN_ADDRESSES = {
  EACO: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
  USDC: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  USDT: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
  SOL: 'So11111111111111111111111111111111111111112'
};

export function useExchange() {
  const { t } = useTranslation();
  const { publicKey, balance } = useWallet();
  
  // Swap state
  const [fromCurrency, setFromCurrency] = useState<Currency>('USDC');
  const [toCurrency, setToCurrency] = useState<Currency>('EACO');
  const [amount, setAmount] = useState<string>('');
  const [rate, setRate] = useState<number | null>(null);
  const [estimatedAmount, setEstimatedAmount] = useState<number | null>(null);
  const [fee, setFee] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  
  // OTC state
  const [otcOrders, setOtcOrders] = useState<OTCOrder[]>(MOCK_OTC_ORDERS);
  const [currentOrder, setCurrentOrder] = useState<Partial<OTCOrder>>({
    type: 'buy',
    currency: 'EACO',
    fiatCurrency: 'USD',
    paymentMethod: 'bank_transfer'
  });
  const [activeTab, setActiveTab] = useState<'order_book' | 'my_orders'>('order_book');

  // AI-powered features state
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [aiPricePrediction, setAiPricePrediction] = useState<any>(null);
  const [aiOrderBookAnalysis, setAiOrderBookAnalysis] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Import mock AI service
  const { mockAiService } = require('@/lib/mockAiService');

  // Fetch real exchange rate from DEX APIs
  const fetchRealRate = async () => {
    if (fromCurrency === toCurrency) {
      setRate(1);
      return 1;
    }

    setIsLoading(true);
    try {
      // Try multiple DEX endpoints and fallback to the first successful response
      const ratePromises = [
        fetchFromOrca(),
        fetchFromRaydium(),
        fetchFromMeteora()
      ];

      // Run all requests in parallel and take the first successful response
      const results = await Promise.allSettled(ratePromises);
      
      for (const result of results) {
        if (result.status === 'fulfilled' && result.value) {
          setRate(result.value);
          return result.value;
        }
      }

      // If all DEX APIs fail, fall back to mock rate
      const mockRate = getMockRate();
      setRate(mockRate);
      return mockRate;
    } catch (error) {
      console.error('Failed to fetch exchange rate:', error);
      const mockRate = getMockRate();
      setRate(mockRate);
      return mockRate;
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch rate from Orca DEX
  const fetchFromOrca = async (): Promise<number | null> => {
    try {
      const response = await axios.get(DEX_ENDPOINTS.ORCA, {
        params: {
          from: TOKEN_ADDRESSES[fromCurrency],
          to: TOKEN_ADDRESSES[toCurrency],
          amount: 1
        }
      });
      return parseFloat(response.data.price);
    } catch (error) {
      console.error('Orca API error:', error);
      return null;
    }
  };

  // Fetch rate from Raydium DEX
  const fetchFromRaydium = async (): Promise<number | null> => {
    try {
      const response = await axios.get(`${DEX_ENDPOINTS.RAYDIUM}/${fromCurrency}/${toCurrency}`);
      return parseFloat(response.data.price);
    } catch (error) {
      console.error('Raydium API error:', error);
      return null;
    }
};

// Fetch rate from Meteora DEX
const fetchFromMeteora = async (): Promise<number | null> => {
  try {
    const response = await axios.get(DEX_ENDPOINTS.METEORA, {
      params: {
        tokenA: TOKEN_ADDRESSES[fromCurrency],
        tokenB: TOKEN_ADDRESSES[toCurrency]
      }
    });
    return parseFloat(response.data.rate);
  } catch (error) {
    console.error('Meteora API error:', error);
    return null;
  }
};

// Get mock rate if API calls fail
const getMockRate = () => {
  const mockRates = {
    'USDC-EACO': 82.34,
    'EACO-USDC': 0.01214,
    'USDT-EACO': 82.31,
    'EACO-USDT': 0.01215,
    'SOL-EACO': 783.5,
    'EACO-SOL': 0.001276,
    'USDC-USDT': 0.9995,
    'USDT-USDC': 1.0005,
    'SOL-USDC': 0.105,
    'USDC-SOL': 9.5238,
    'SOL-USDT': 0.1049,
    'USDT-SOL': 9.533
  };

  const rateKey = `${fromCurrency}-${toCurrency}` as keyof typeof mockRates;
  return mockRates[rateKey] || 0;
};

// Calculate exchange rate and fees
const calculateRate = async () => {
  if (fromCurrency === toCurrency) {
    setRate(1);
    setEstimatedAmount(amount ? parseFloat(amount) : null);
    setFee(0);
    return;
  }

  const exchangeRate = await fetchRealRate();
  
  if (exchangeRate && amount) {
    const amountNum = parseFloat(amount);
    const calculatedAmount = amountNum * exchangeRate;
    const calculatedFee = (calculatedAmount * FEE_STRUCTURE.swap) / 100;
    
    setEstimatedAmount(parseFloat((calculatedAmount - calculatedFee).toFixed(6)));
    setFee(parseFloat(calculatedFee.toFixed(6)));
  }
};

// Get current rate with loading state
const getRate = async () => {
  if (!amount) {
    toast.error(t('exchange.amount_required'));
    return;
  }
  
  setIsLoading(true);
  try {
    await calculateRate();
  } catch (error) {
    console.error('Error calculating rate:', error);
    toast.error(t('exchange.rate_fetch_failed'));
  } finally {
    setIsLoading(false);
  }
};

// Swap currencies
const swapCurrencies = () => {
  setFromCurrency(toCurrency);
  setToCurrency(fromCurrency);
};

// Execute token swap
const executeExchange = () => {
  if (!publicKey) {
    toast.error(t('wallet.WalletNotConnectedError'));
    return;
  }

  if (!amount || !rate || !estimatedAmount || !fee) {
    toast.error(t('exchange.missing_fields'));
    return;
  }

  // Check if user has enough balance
  if (balance && balance[fromCurrency] < parseFloat(amount)) {
    toast.error(t('exchange.insufficient_balance'));
    return;
  }

  setIsLoading(true);
  
  // Simulate API call delay
  setTimeout(() => {
    try {
      // Create transaction object with fees
      const newTransaction: Transaction = {
        id: Date.now().toString(),
        type: 'swap',
        hash: '0x' + Math.random().toString(36).substring(2, 10).toUpperCase(),
        date: new Date().toISOString(),
        fromCurrency,
        toCurrency,
        amount: parseFloat(amount),
        receivedAmount: estimatedAmount,
        status: 'confirmed',
        rate,
        fees: {
          amount: fee,
          currency: toCurrency,
          percentage: FEE_STRUCTURE.swap
        },
        fromAddress: publicKey,
        toAddress: publicKey // In a real scenario, this would be the DEX address
      };

      // Update transactions list
      setTransactions(prev => [newTransaction, ...prev]);
      
      // Clear form
      setAmount('');
      setEstimatedAmount(null);
      setFee(null);
      
      toast.success(t('common.success'));
    } catch (error) {
      console.error('Exchange failed:', error);
      toast.error(t('common.error'));
    } finally {
      setIsLoading(false);
    }
  }, 1500);
};

// OTC Order Functions

// Create new OTC order
const createOTCOrder = () => {
  if (!publicKey || !currentOrder.type || !currentOrder.currency || 
      !currentOrder.fiatCurrency || !currentOrder.amount || !currentOrder.price) {
    toast.error(t('otc.missing_order_fields'));
    return;
  }

  // Check if user has enough EACO to pay fees
  if (balance && balance.EACO < FEE_STRUCTURE.otc / 100) {
    toast.error(t('otc.insufficient_eaco_for_fees'));
    return;
  }

  setIsLoading(true);

  try {
    // Calculate total amount and fees
    const amountNum = Number(currentOrder.amount);
    const priceNum = Number(currentOrder.price);
    const total = amountNum * priceNum;
    const feeAmount = (amountNum * FEE_STRUCTURE.otc) / 100;

    // Create new order with fee information
    const newOrder: OTCOrder = {
      id: `otc-${Date.now()}`,
      type: currentOrder.type,
      creator: publicKey,
      currency: currentOrder.currency as Currency,
      fiatCurrency: currentOrder.fiatCurrency,
      amount: amountNum,
      price: priceNum,
      total,
      paymentMethod: currentOrder.paymentMethod || '',
      status: 'open',
      createdAt: new Date().toISOString(),
      fees: {
        amount: feeAmount,
        currency: 'EACO',
        percentage: FEE_STRUCTURE.otc
      }
    };

    // Add to orders list
    setOtcOrders(prev => [newOrder, ...prev]);
    
    // Reset current order
    setCurrentOrder({
      type: currentOrder.type,
      currency: currentOrder.currency as Currency,
      fiatCurrency: currentOrder.fiatCurrency,
      paymentMethod: currentOrder.paymentMethod
    });

    toast.success(t('otc.order_created_successfully'));
    toast.info(t('otc.fee_deduction_info', { amount: feeAmount.toFixed(4) }));
  } catch (error) {
    console.error('Failed to create OTC order:', error);
    toast.error(t('otc.order_creation_failed'));
  } finally {
    setIsLoading(false);
  }
};

// Match OTC order
const matchOTCOrder = (order: OTCOrder) => {
  if (!publicKey || order.creator === publicKey) {
    toast.error(t('otc.cannot_match_own_order'));
    return;
  }

  setIsLoading(true);

  try {
    // In a real application, this would:
    // 1. Verify user has sufficient funds
    // 2. Create escrow contract
    // 3. Update order status
    
    // Update order status
    const updatedOrders = otcOrders.map(o => 
      o.id === order.id 
        ? { 
            ...o, 
            status: 'matched', 
            matchedAt: new Date().toISOString(),
            counterparty: publicKey,
            escrowId: `escrow-${Date.now()}`
          } 
        : o
    );

    setOtcOrders(updatedOrders);
    
    // Create transaction record
    const otcTransaction: Transaction = {
      id: Date.now().toString(),
      type: 'otc',
      hash: '0x' + Math.random().toString(36).substring(2, 10).toUpperCase(),
      date: new Date().toISOString(),
      fromCurrency: order.currency,
      toCurrency: order.currency, // This would be the counterparty's currency
      fiatCurrency: order.fiatCurrency,
      amount: order.amount,
      receivedAmount: order.amount,
      status: 'escrow',
      rate: order.price,
      fees: {
        amount: (order.amount * order.price * FEE_STRUCTURE.otc) / 100,
        currency: order.currency,
        percentage: FEE_STRUCTURE.otc
      },
      fromAddress: order.creator,
      toAddress: publicKey,
      otcOrderId: order.id,
      escrowAddress: `escrow-${Date.now()}`
    };

    setTransactions(prev => [otcTransaction, ...prev]);
    
    toast.success(t('otc.order_matched'));
  } catch (error) {
    console.error('Failed to match OTC order:', error);
    toast.error(t('otc.order_match_failed'));
  } finally {
    setIsLoading(false);
  }
};

// Release escrow funds
const releaseEscrow = (orderId: string) => {
  setIsLoading(true);
  
  try {
    // In a real application, this would interact with the escrow smart contract
    const updatedOrders = otcOrders.map(o => 
      o.id === orderId ? { ...o, status: 'completed' } : o
    );
    
    // Update transaction status
    const updatedTransactions = transactions.map(tx => 
      tx.otcOrderId === orderId ? { ...tx, status: 'confirmed' } : tx
    );
    
    setOtcOrders(updatedOrders);
    setTransactions(updatedTransactions);
    
    toast.success(t('otc.funds_released'));
  } catch (error) {
    console.error('Failed to release escrow:', error);
    toast.error(t('otc.funds_release_failed'));
  } finally {
    setIsLoading(false);
  }
};

// Open dispute for an order
const openDispute = (orderId: string, reason: string) => {
  if (!publicKey) return;
  
  setIsLoading(true);
  
  try {
    const updatedOrders = otcOrders.map(o => 
      o.id === orderId 
        ? { 
            ...o, 
            status: 'disputed',
            disputeReason: reason,
            disputedAt: new Date().toISOString(),
            disputedBy: publicKey
          } 
        : o
    );
    
    setOtcOrders(updatedOrders);
    toast.info(t('otc.dispute_opened'));
    
    // In a real application, this would notify community arbitrators
  } catch (error) {
    console.error('Failed to open dispute:', error);
    toast.error(t('otc.dispute_failed'));
  } finally {
    setIsLoading(false);
  }
};

/**
 * Fetch AI-powered market analysis
 */
const fetchAiMarketAnalysis = async (currency: string = 'EACO') => {
  if (isAnalyzing) return;
  
  setIsAnalyzing(true);
  try {
    const analysis = await mockAiService.getMarketAnalysis(currency);
    setAiAnalysis(analysis);
    return analysis;
  } catch (error) {
    console.error('Failed to fetch AI market analysis:', error);
    toast.error(t('ai.analysis_failed'));
    return null;
  } finally {
    setIsAnalyzing(false);
  }
};

/**
 * Fetch AI-powered price prediction
 */
const fetchAiPricePrediction = async (baseCurrency: string, targetCurrency: string) => {
  if (isAnalyzing) return;
  
  setIsAnalyzing(true);
  try {
    const prediction = await mockAiService.getPricePrediction(baseCurrency, targetCurrency);
    setAiPricePrediction(prediction);
    return prediction;
  } catch (error) {
    console.error('Failed to fetch AI price prediction:', error);
    toast.error(t('ai.prediction_failed'));
    return null;
  } finally {
    setIsAnalyzing(false);
  }
};

/**
 * Analyze order book with AI
 */
const analyzeOrderBookWithAi = async () => {
  if (isAnalyzing) return;
  
  setIsAnalyzing(true);
  try {
    const analysis = await mockAiService.analyzeOrderBook(otcOrders);
    setAiOrderBookAnalysis(analysis);
    return analysis;
  } catch (error) {
    console.error('Failed to analyze order book with AI:', error);
    toast.error(t('ai.order_book_analysis_failed'));
    return null;
  } finally {
    setIsAnalyzing(false);
  }
};

  return {
  // Swap state and functions
  fromCurrency,
  toCurrency,
  amount,
  rate,
  estimatedAmount,
  fee,
  isLoading,
  transactions,
  setFromCurrency,
  setToCurrency,
  setAmount,
  getRate,
  swapCurrencies,
  executeExchange,
  
  // OTC state and functions
  otcOrders,
  currentOrder,
  activeTab,
  setCurrentOrder,
  setActiveTab,
  createOTCOrder,
  matchOTCOrder,
  releaseEscrow,
  openDispute,
  myOtcOrders: otcOrders.filter(order => order.creator === publicKey),
  
  // AI-powered features
  aiAnalysis,
  aiPricePrediction,
  aiOrderBookAnalysis,
  isAnalyzing,
  fetchAiMarketAnalysis,
  fetchAiPricePrediction,
  analyzeOrderBookWithAi
};
}