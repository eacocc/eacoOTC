import { useState, useEffect } from 'react';
import { useWallet as useSolanaWallet } from '@solana/wallet-adapter-react';
import { WalletNotConnectedError, WalletError } from '@solana/wallet-adapter-base';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { Connection, PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';
import axios from 'axios';

// Define balance type with supported currencies
export type WalletBalance = {
  EACO: number;
  USDC: number;
  USDT: number;
  SOL: number;
};

// Define DEX API endpoints from project documentation
const DEX_ENDPOINTS = {
  ORCA: 'https://www.orca.so/api',
  RAYDIUM: 'https://api.raydium.io',
  METEORA: 'https://app.meteora.ag/api'
};

export function useWallet() {
  const { t } = useTranslation();
  const wallet = useSolanaWallet();
  const [balance, setBalance] = useState<WalletBalance | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'connecting' | 'connected' | 'error'>('idle');
  const [connection, setConnection] = useState<Connection | null>(null);

  // Initialize Solana connection
  useEffect(() => {
    const solanaConnection = new Connection('https://api.mainnet-beta.solana.com', 'confirmed');
    setConnection(solanaConnection);
  }, []);

  // Fetch SOL balance from blockchain
  const fetchSOLBalance = async (publicKey: PublicKey): Promise<number> => {
    try {
      if (!connection) throw new Error('Solana connection not initialized');
      
      const balanceLamports = await connection.getBalance(publicKey);
      return balanceLamports / LAMPORTS_PER_SOL;
    } catch (error) {
      console.error('Failed to fetch SOL balance:', error);
      return 0;
    }
  };

  // Fetch token balance from DEX API
  const fetchTokenBalance = async (publicKey: string, tokenSymbol: string): Promise<number> => {
    try {
      // In a real implementation, this would call the actual DEX API
      // Using mock data for demonstration based on project documentation
      const tokenAddresses = {
        EACO: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
        USDC: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
        USDT: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB'
      };

      // Mock API call to DEX endpoint
      const response = await axios.get(`${DEX_ENDPOINTS.ORCA}/v1/accounts/${publicKey}/tokens/${tokenAddresses[tokenSymbol as keyof typeof tokenAddresses]}`);
      return response.data.balance || 0;
    } catch (error) {
      console.error(`Failed to fetch ${tokenSymbol} balance:`, error);
      return 0;
    }
  };

  // Fetch complete wallet balance
  const fetchBalance = async (): Promise<WalletBalance | null> => {
    if (!wallet.publicKey) throw new WalletNotConnectedError();
    
    setIsLoading(true);
    try {
      const publicKeyStr = wallet.publicKey.toString();
      
      // Fetch all balances in parallel
      const [solBalance, eacoBalance, usdcBalance, usdtBalance] = await Promise.all([
        fetchSOLBalance(wallet.publicKey),
        fetchTokenBalance(publicKeyStr, 'EACO'),
        fetchTokenBalance(publicKeyStr, 'USDC'),
        fetchTokenBalance(publicKeyStr, 'USDT')
      ]);

      const balances: WalletBalance = {
        SOL: parseFloat(solBalance.toFixed(6)),
        EACO: parseFloat(eacoBalance.toFixed(6)),
        USDC: parseFloat(usdcBalance.toFixed(6)),
        USDT: parseFloat(usdtBalance.toFixed(6))
      };

      setBalance(balances);
      return balances;
    } catch (error) {
      console.error('Failed to fetch balance:', error);
      toast.error(t('wallet.balance_fetch_failed'));
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Connect wallet handler with error states
  const connectWallet = async () => {
    if (connectionStatus === 'connecting') return;
    
    setConnectionStatus('connecting');
    try {
      await wallet.connect();
      toast.success(t('wallet.connected'));
      setConnectionStatus('connected');
      await fetchBalance();
    } catch (error) {
      console.error('Wallet connection failed:', error);
      
      if (error instanceof WalletError) {
        toast.error(t(`wallet.errors.${error.name}`) || t('wallet.connection_failed'));
      } else {
        toast.error(t('wallet.connection_failed'));
      }
      
      setConnectionStatus('error');
    }
  };

  // Disconnect wallet handler with cleanup
  const disconnectWallet = async () => {
    if (wallet.connected) {
      try {
        await wallet.disconnect();
        toast.info(t('wallet.disconnected'));
      } catch (error) {
        console.error('Error disconnecting wallet:', error);
        toast.error(t('wallet.disconnection_failed'));
      } finally {
        setConnectionStatus('idle');
        setBalance(null);
      }
    }
  };

  // Auto-refresh balance every 30 seconds when connected
  useEffect(() => {
    if (wallet.connected && connectionStatus === 'connected') {
      const intervalId = setInterval(fetchBalance, 30000);
      return () => clearInterval(intervalId);
    }
  }, [wallet.connected, connectionStatus]);

  return {
    publicKey: wallet.publicKey?.toString() || null,
    connected: wallet.connected,
    connectionStatus,
    balance,
    isLoading,
    connectWallet,
    disconnectWallet,
    fetchBalance,
    connection
  };
}