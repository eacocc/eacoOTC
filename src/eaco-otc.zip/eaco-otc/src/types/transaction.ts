import { Currency } from './currency';

// Extended transaction status for OTC
export type TransactionStatus = 'pending' | 'confirmed' | 'failed' | 'escrow' | 'disputed' | 'refunded';

// OTC Order type
export interface FeeInfo {
  amount: number;
  currency: Currency;
  percentage: number;
}

export interface OTCOrder {
  id: string;
  type: 'buy' | 'sell';
  creator: string; // Wallet address
  currency: Currency;
  fiatCurrency: string; // e.g. USD, EUR, VND
  amount: number;
  price: number; // Price per unit in fiat
  total: number; // Total fiat amount
  paymentMethod: string;
  status: 'open' | 'matched' | 'completed' | 'cancelled' | 'disputed' | 'arbitration';
  createdAt: string;
  matchedAt?: string;
  completedAt?: string;
  counterparty?: string; // Wallet address of counterparty
  escrowId?: string;
  fees?: FeeInfo;
  disputeReason?: string;
  arbitrators?: string[];
}

// Enhanced transaction interface with OTC support
export interface Transaction {
  id: string;
  type: 'swap' | 'otc';
  hash: string;
  date: string;
  fromCurrency: Currency;
  toCurrency: Currency;
  fiatCurrency?: string; // For OTC transactions
  amount: number;
  receivedAmount: number;
  status: TransactionStatus;
  rate: number;
  fees: {
    amount: number;
    currency: Currency;
    percentage: number;
  };
  fromAddress: string;
  toAddress: string;
  otcOrderId?: string; // Link to OTC order if applicable
  escrowAddress?: string;
}

// Reputation system interface
export interface UserReputation {
  userId: string;
  rating: number; // 0-5
  completedTransactions: number;
  disputedTransactions: number;
  successfulTransactions: number;
  disputeWinRate: number;
}

// Mock transaction data for demonstration
export const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: '1',
    type: 'swap',
    hash: '0xabc123...',
    date: '2025-09-01T10:30:00Z',
    fromCurrency: 'USDC',
    toCurrency: 'EACO',
    amount: 100,
    receivedAmount: 8234,
    status: 'confirmed',
    rate: 82.34,
    fees: {
      amount: 1.2,
      currency: 'USDC',
      percentage: 0.5
    },
    fromAddress: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    toAddress: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH'
  },
  {
    id: '2',
    type: 'otc',
    hash: '0xdef456...',
    date: '2025-09-02T14:15:00Z',
    fromCurrency: 'SOL',
    toCurrency: 'EACO',
    fiatCurrency: 'USD',
    amount: 2,
    receivedAmount: 1567,
    status: 'confirmed',
    rate: 783.5,
    fees: {
      amount: 15.67,
      currency: 'EACO',
      percentage: 1.0
    },
    fromAddress: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    toAddress: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    otcOrderId: 'otc-12345'
  },
  {
    id: '3',
    type: 'otc',
    hash: '0xghi789...',
    date: '2025-09-03T09:45:00Z',
    fromCurrency: 'EACO',
    toCurrency: 'USDT',
    fiatCurrency: 'VND',
    amount: 5000,
    receivedAmount: 60.7,
    status: 'escrow',
    rate: 0.01214,
    fees: {
      amount: 6.07,
      currency: 'USDT',
      percentage: 1.0
    },
    fromAddress: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    toAddress: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    otcOrderId: 'otc-67890',
    escrowAddress: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH'
  }
];

// Mock OTC orders
export const MOCK_OTC_ORDERS: OTCOrder[] = [
  {
    id: 'otc-12345',
    type: 'sell',
    creator: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    currency: 'SOL',
    fiatCurrency: 'USD',
    amount: 2,
    price: 120,
    total: 240,
    paymentMethod: 'bank_transfer',
    status: 'completed',
    createdAt: '2025-09-02T14:00:00Z',
    matchedAt: '2025-09-02T14:10:00Z',
    counterparty: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH'
  },
  {
    id: 'otc-67890',
    type: 'buy',
    creator: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    currency: 'USDT',
    fiatCurrency: 'VND',
    amount: 60.7,
    price: 24850,
    total: 1510395,
    paymentMethod: 'mobile_money',
    status: 'matched',
    createdAt: '2025-09-03T09:30:00Z',
    matchedAt: '2025-09-03T09:40:00Z',
    counterparty: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH'
  },
  {
    id: 'otc-54321',
    type: 'sell',
    creator: 'DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    currency: 'EACO',
    fiatCurrency: 'EUR',
    amount: 1000,
    price: 0.85,
    total: 850,
    paymentMethod: 'revolut',
    status: 'open',
    createdAt: '2025-09-03T11:20:00Z'
  }
];