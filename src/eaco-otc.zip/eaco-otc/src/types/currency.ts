export type Currency = 'EACO' | 'USDC' | 'USDT' | 'SOL';

export interface CurrencyInfo {
  symbol: Currency;
  name: string;
  icon: string;
  decimals: number;
}

export const SUPPORTED_CURRENCIES: Record<Currency, CurrencyInfo> = {
  EACO: {
    symbol: 'EACO',
    name: 'EACO',
    icon: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=EACO%20token%20logo%2C%20blue%20color%2C%20modern%20design&sign=a4b2fc8f12d6288699b521e107653eff',
    decimals: 9
  },
  USDC: {
    symbol: 'USDC',
    name: 'USD Coin',
    icon: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=USDC%20token%20logo%2C%20blue%20color%2C%20modern%20design&sign=2e9b33fccaea5c1bacdd042af06940f6',
    decimals: 6
  },
  USDT: {
    symbol: 'USDT',
    name: 'Tether',
    icon: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=USDT%20token%20logo%2C%20green%20color%2C%20modern%20design&sign=7dda714e4895cbab5ac0810288ba4305',
    decimals: 6
  },
  SOL: {
    symbol: 'SOL',
    name: 'Solana',
    icon: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=SOL%20token%20logo%2C%20purple%20color%2C%20modern%20design&sign=8a60fbb17347c338d8a268319b68d3d6',
    decimals: 9
  }
};