import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import translationEN from './en.json';
import translationZH from './zh.json';
import translationES from './es.json';
import translationVI from './vi.json';

// 配置语言资源
const resources = {
  en: {
    translation: translationEN
  },
  zh: {
    translation: translationZH
  },
  es: {
    translation: translationES
  },
  vi: {
    translation: translationVI
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en', // 默认语言
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false // 不需要转义
    }
  });

export default i18n;